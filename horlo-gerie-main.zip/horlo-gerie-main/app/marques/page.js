'use client';
import { useEffect, useState } from 'react';
import { getWatches } from '../../lib/supabase';
import { MAISONS, MICRO } from '../../lib/site-data';

export default function Marques() {
  const [watches, setWatches] = useState([]);
  useEffect(() => { getWatches().then(setWatches); }, []);

  const counts = {};
  watches.forEach(w => { counts[w.marque] = (counts[w.marque] || 0) + 1; });

  return (
    <div className="wrap" style={{ paddingBlock: 'clamp(26px,3.2vw,48px) clamp(60px,7vw,100px)' }}>
      <div style={{ maxWidth: '52em' }}>
        <span className="eyebrow">Découvrir</span>
        <h1 style={{ fontSize: 'clamp(32px,4.2vw,58px)', marginTop: 14 }}>Les marques que nous prenons</h1>
        <p className="intro" style={{ margin: '16px 0 0', fontSize: 15, color: 'var(--steel-text)' }}>
          Nous ne prenons pas tout. Une montre entre en dépôt si elle se revend — c’est-à-dire si sa maison
          tient dans le temps, si les pièces détachées existent encore, et si le marché sait ce qu’elle vaut.
          Voici les maisons que nous suivons, et ce qui est disponible aujourd’hui.
        </p>
      </div>

      <h2 className="brand-sec-title">Maisons établies</h2>
      <div className="brandlist">
        {MAISONS.map(m => {
          const n = counts[m.n] || 0;
          return (
            <a
              key={m.n}
              className={`brandtile${n ? '' : ' off'}`}
              href={n
                ? `/boutique/?brand=${encodeURIComponent(m.n)}`
                : `mailto:contact@horlo-gerie.fr?subject=${encodeURIComponent('Recherche ' + m.n)}`}
            >
              <span className="bn">{m.n}</span>
              <span className="bc">{m.c}</span>
              <span className="bs">{n ? `${n} pièce${n > 1 ? 's' : ''} en stock` : 'Sur demande'}</span>
            </a>
          );
        })}
      </div>

      <div className="micro">
        <div className="micro-head">
          <div>
            <span className="eyebrow">Espace dédié</span>
            <h2>Micro-marques haut de gamme</h2>
            <p>
              La partie la plus intéressante du marché depuis dix ans. Des maisons indépendantes qui produisent
              quelques centaines de pièces par an, avec des finitions de cadran, des émaux ou des mouvements que
              les grandes séries ne permettent plus. Elles se revendent bien parce qu’elles sont rares — mais
              uniquement si la pièce est complète et honnêtement décrite. C’est exactement notre métier.
            </p>
          </div>
          <div className="micro-facts">
            <div><b>Complet exigé</b><span>Boîte, papiers et carte de garantie obligatoires pour ces références.</span></div>
            <div><b>Séries limitées</b><span>Numéro de série et taille de série relevés sur chaque pièce.</span></div>
            <div><b>Cote suivie</b><span>Prix calés sur les ventes réelles, pas sur le tarif boutique.</span></div>
          </div>
        </div>
        <div className="microgrid">
          {MICRO.map(m => (
            <div className="microcard" key={m.n}>
              <div className="mtop"><span className="mn">{m.n}</span><span className="mp">{m.p}</span></div>
              <p>{m.d}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="search-box" style={{ marginTop: 'clamp(32px,4vw,56px)' }}>
        <div>
          <span className="eyebrow">Votre marque n’y est pas ?</span>
          <h3>Nous regardons au cas par cas</h3>
          <p>Cette liste n’est pas fermée. Envoyez-nous la référence et quelques photos : nous vous disons sous 48 h si nous la prenons en dépôt, et à quel prix nous pensons la vendre.</p>
        </div>
        <div className="side">
          <a className="btn" href="mailto:contact@horlo-gerie.fr?subject=Proposition%20de%20marque">Nous soumettre une pièce</a>
          <p className="fine">Réponse sous 48 h, sans engagement.</p>
        </div>
      </div>
    </div>
  );
}
