'use client';
import { useEffect, useMemo, useState } from 'react';
import {
  sendMagicLink, signOut, getSession, onAuthChange, checkIsAdmin,
  getAllWatchesAdmin, deleteWatch, deleteWatches, setWatchStatus, setWatchesStatus,
  markWatchSold, duplicateWatch, checkWatch, listeFr, eur,
} from '../../lib/supabase';
import WatchForm from '../../components/WatchForm';

const STATUTS = [
  { key: 'tous', label: 'Toutes' },
  { key: 'brouillon', label: 'Brouillons' },
  { key: 'publie', label: 'Publiées' },
  { key: 'vendu', label: 'Vendues' },
];

const TRIS = [
  { key: 'recent', label: 'Ajout récent' },
  { key: 'ancien', label: 'Ajout ancien' },
  { key: 'maj', label: 'Modifiée en dernier' },
  { key: 'prix-desc', label: 'Prix décroissant' },
  { key: 'prix-asc', label: 'Prix croissant' },
  { key: 'marque', label: 'Marque (A→Z)' },
];

const LABEL_STATUT = { brouillon: 'Brouillon', publie: 'Publiée', vendu: 'Vendue' };

// Recherche insensible aux accents et à la casse
function norm(s) {
  return (s || '').toString().normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

function fermerMenu(e) {
  const d = e.currentTarget.closest('details');
  if (d) d.open = false;
}

function Login() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setErr('');
    const { error } = await sendMagicLink(email);
    if (error) setErr(error.message); else setSent(true);
  }

  return (
    <div className="wrap" style={{ padding: '60px 0', maxWidth: 420 }}>
      <span className="eyebrow">Espace privé</span>
      <h1>Connexion admin</h1>
      {sent ? (
        <p>Un lien de connexion a été envoyé à <b>{email}</b>. Ouvre-le depuis cet appareil pour te connecter.</p>
      ) : (
        <form onSubmit={handleSubmit} className="watch-form">
          <label className="block">Adresse e-mail admin
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="toi@horlo-gerie.fr" />
          </label>
          {err && <p className="err">{err}</p>}
          <button className="btn solid" style={{ marginTop: 14 }}>Recevoir le lien de connexion</button>
        </form>
      )}
    </div>
  );
}

function Dashboard({ email }) {
  const [watches, setWatches] = useState(null);
  const [editing, setEditing] = useState(undefined); // undefined = liste, null = nouvelle pièce, objet = édition
  const [filter, setFilter] = useState('tous');
  const [query, setQuery] = useState('');
  const [tri, setTri] = useState('recent');
  const [selected, setSelected] = useState([]);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null);

  async function reload() { setWatches(await getAllWatchesAdmin()); }
  useEffect(() => { reload(); }, []);

  function flash(msg) {
    setToast(msg);
    setTimeout(() => setToast(t => (t === msg ? null : t)), 4000);
  }

  // Exécute une action, affiche l'erreur ou la confirmation, recharge la liste
  async function run(message, fn) {
    setBusy(true);
    const res = await fn();
    setBusy(false);
    if (res && res.error) { flash('Erreur : ' + res.error.message); return false; }
    await reload();
    flash(message);
    return true;
  }

  const counts = useMemo(() => {
    const all = watches || [];
    return {
      tous: all.length,
      brouillon: all.filter(w => w.status === 'brouillon').length,
      publie: all.filter(w => w.status === 'publie').length,
      vendu: all.filter(w => w.status === 'vendu').length,
    };
  }, [watches]);

  const totaux = useMemo(() => {
    const all = watches || [];
    return {
      vitrine: all.filter(w => w.status === 'publie')
        .reduce((s, w) => s + Number(w.prix || 0), 0),
      ventes: all.filter(w => w.status === 'vendu')
        .reduce((s, w) => s + Number(w.vendu_prix != null ? w.vendu_prix : w.prix || 0), 0),
      aRevoir: all.filter(w => w.status === 'publie' && !checkWatch(w).complete).length,
    };
  }, [watches]);

  const shown = useMemo(() => {
    let list = (watches || []).filter(w => filter === 'tous' || w.status === filter);
    const q = norm(query).trim();
    if (q) {
      const mots = q.split(/\s+/);
      list = list.filter(w => {
        const hay = norm([w.marque, w.modele, w.ref, w.annee, w.calibre, w.slug].join(' '));
        return mots.every(m => hay.includes(m));
      });
    }
    const recent = (a, b, champ) => new Date(b[champ] || 0) - new Date(a[champ] || 0);
    const out = [...list];
    if (tri === 'recent') out.sort((a, b) => recent(a, b, 'created_at'));
    else if (tri === 'ancien') out.sort((a, b) => -recent(a, b, 'created_at'));
    else if (tri === 'maj') out.sort((a, b) => recent(a, b, 'updated_at'));
    else if (tri === 'prix-desc') out.sort((a, b) => Number(b.prix || 0) - Number(a.prix || 0));
    else if (tri === 'prix-asc') out.sort((a, b) => Number(a.prix || 0) - Number(b.prix || 0));
    else if (tri === 'marque') out.sort((a, b) => (a.marque + ' ' + a.modele).localeCompare(b.marque + ' ' + b.modele, 'fr'));
    return out;
  }, [watches, filter, query, tri]);

  const choisies = shown.filter(w => selected.includes(w.id));
  const toutesChoisies = shown.length > 0 && choisies.length === shown.length;

  function basculer(id) {
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }
  function basculerTout() {
    setSelected(toutesChoisies ? [] : shown.map(w => w.id));
  }

  /* ── actions sur une pièce ── */

  function publier(w) {
    const { manquants } = checkWatch(w);
    if (manquants.length) {
      flash(`${w.marque} ${w.modele} ne peut pas être publiée : il manque ${listeFr(manquants)}.`);
      return;
    }
    run(`${w.marque} ${w.modele} est en ligne.`, () => setWatchStatus(w.id, 'publie'));
  }

  function depublier(w) {
    run(`${w.marque} ${w.modele} repasse en brouillon.`, () => setWatchStatus(w.id, 'brouillon'));
  }

  function vendre(w) {
    const prix = w.vendu_prix != null ? w.vendu_prix : w.prix;
    if (!confirm(`Marquer ${w.marque} ${w.modele} vendue à ${eur(prix)}, aujourd'hui ?\n\nLe prix de vente et la date restent modifiables dans la fiche.`)) return;
    run(`${w.marque} ${w.modele} est passée en vendue.`, () => markWatchSold(w));
  }

  function dupliquer(w) {
    run(`Copie de ${w.marque} ${w.modele} créée en brouillon.`, () => duplicateWatch(w));
  }

  function supprimer(w) {
    if (!confirm(`Supprimer définitivement ${w.marque} ${w.modele} ?`)) return;
    run('Pièce supprimée.', () => deleteWatch(w.id));
  }

  /* ── actions groupées ── */

  async function groupePublier() {
    const cibles = choisies.filter(w => w.status !== 'publie');
    if (!cibles.length) { flash('Les pièces sélectionnées sont déjà publiées.'); return; }
    const pretes = cibles.filter(w => checkWatch(w).publiable);
    const bloquees = cibles.length - pretes.length;
    if (!pretes.length) {
      flash(`Aucune publication : ${bloquees} annonce${bloquees > 1 ? 's' : ''} incomplète${bloquees > 1 ? 's' : ''} (photo, prix ou description).`);
      return;
    }
    const ok = await run(
      bloquees
        ? `${pretes.length} annonce${pretes.length > 1 ? 's' : ''} publiée${pretes.length > 1 ? 's' : ''}, ${bloquees} laissée${bloquees > 1 ? 's' : ''} de côté car incomplète${bloquees > 1 ? 's' : ''}.`
        : `${pretes.length} annonce${pretes.length > 1 ? 's' : ''} publiée${pretes.length > 1 ? 's' : ''}.`,
      () => setWatchesStatus(pretes.map(w => w.id), 'publie'),
    );
    if (ok) setSelected([]);
  }

  async function groupeDepublier() {
    const cibles = choisies.filter(w => w.status !== 'brouillon');
    if (!cibles.length) { flash('Les pièces sélectionnées sont déjà en brouillon.'); return; }
    const ok = await run(
      `${cibles.length} pièce${cibles.length > 1 ? 's' : ''} repassée${cibles.length > 1 ? 's' : ''} en brouillon.`,
      () => setWatchesStatus(cibles.map(w => w.id), 'brouillon'),
    );
    if (ok) setSelected([]);
  }

  async function groupeSupprimer() {
    if (!confirm(`Supprimer définitivement ${choisies.length} pièce${choisies.length > 1 ? 's' : ''} ?`)) return;
    const ok = await run(
      `${choisies.length} pièce${choisies.length > 1 ? 's' : ''} supprimée${choisies.length > 1 ? 's' : ''}.`,
      () => deleteWatches(choisies.map(w => w.id)),
    );
    if (ok) setSelected([]);
  }

  if (editing !== undefined) {
    return (
      <div className="wrap" style={{ padding: '32px 0' }}>
        <WatchForm
          watch={editing}
          onCancel={() => setEditing(undefined)}
          onSaved={() => { setEditing(undefined); reload(); }}
        />
      </div>
    );
  }

  return (
    <div className="wrap" style={{ padding: '32px 0' }}>
      <div className="admin-head">
        <div>
          <span className="eyebrow">Espace admin — {email}</span>
          <h1>Gestion des annonces</h1>
        </div>
        <div className="admin-head-actions">
          <a className="btn ghost" href="/admin/messages/">Messages</a>
          <a className="btn ghost" href="/admin/visiteurs/">Visiteurs</a>
          <a className="btn ghost" href="/admin/clients/">Rechercher un client</a>
          <button className="btn solid" onClick={() => setEditing(null)}>+ Ajouter une pièce</button>
          <button className="btn ghost" onClick={() => signOut()}>Déconnexion</button>
        </div>
      </div>

      <div className="admin-stats">
        <div><span className="k">En vitrine</span><b>{counts.publie} {counts.publie > 1 ? 'pièces' : 'pièce'} · {eur(totaux.vitrine)}</b></div>
        <div><span className="k">Brouillons</span><b>{counts.brouillon}</b></div>
        <div><span className="k">Vendues</span><b>{counts.vendu} · {eur(totaux.ventes)}</b></div>
        <div className={totaux.aRevoir ? 'alerte' : ''}>
          <span className="k">Publiées à compléter</span><b>{totaux.aRevoir}</b>
        </div>
      </div>

      <div className="admin-bar">
        <input
          className="asearch"
          type="search"
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Rechercher une marque, un modèle, une référence…"
        />
        <label className="asort">Trier par
          <select value={tri} onChange={e => setTri(e.target.value)}>
            {TRIS.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
          </select>
        </label>
      </div>

      <div className="admin-filters">
        {STATUTS.map(s => (
          <button
            key={s.key}
            className={`chip${filter === s.key ? ' active' : ''}`}
            onClick={() => setFilter(s.key)}
          >
            {s.label} <span className="n">{counts[s.key]}</span>
          </button>
        ))}
      </div>

      {watches === null ? (
        <p className="empty">Chargement…</p>
      ) : shown.length === 0 ? (
        <p className="empty">
          {query
            ? <>Aucune pièce ne correspond à « {query} ». <button className="lien" onClick={() => setQuery('')}>Effacer la recherche</button></>
            : 'Aucune pièce dans cette catégorie.'}
        </p>
      ) : (
        <>
          <div className="alist-count">
            {shown.length} {shown.length > 1 ? 'pièces affichées' : 'pièce affichée'}
            {query || filter !== 'tous' ? ` sur ${counts.tous} au total` : ''}
          </div>

          <div className="alist">
            <div className="alist-head">
              <label className="cbox" title="Tout sélectionner">
                <input type="checkbox" checked={toutesChoisies} onChange={basculerTout} />
              </label>
              <span />
              <span>Pièce</span>
              <span>Prix</span>
              <span>Statut</span>
              <span />
            </div>

            {shown.map(w => {
              const c = checkWatch(w);
              const coche = selected.includes(w.id);
              return (
                <div key={w.id} className={`arow${coche ? ' on' : ''}`}>
                  <label className="cbox">
                    <input type="checkbox" checked={coche} onChange={() => basculer(w.id)} />
                  </label>

                  <div className="aph">
                    {w.photos && w.photos[0]
                      ? <img src={w.photos[0]} alt="" />
                      : <div className="ph-empty" />}
                    {w.photos && w.photos.length > 1 && <span className="phn">{w.photos.length}</span>}
                  </div>

                  <div className="ainfo">
                    <div className="atitre"><b>{w.marque}</b> {w.modele}</div>
                    <div className="sub">{[w.ref, w.annee].filter(Boolean).join(' · ') || '—'}</div>
                    {!c.publiable && (
                      <span className="flag miss">Il manque {listeFr(c.manquants)}</span>
                    )}
                    {c.publiable && c.aCompleter.length > 0 && (
                      <span className="flag todo">À compléter : {listeFr(c.aCompleter)}</span>
                    )}
                  </div>

                  <div className="aprice">
                    {eur(w.prix)}
                    {w.status === 'vendu' && w.vendu_prix != null && Number(w.vendu_prix) !== Number(w.prix) && (
                      <div className="sub">vendue {eur(w.vendu_prix)}</div>
                    )}
                  </div>

                  <div className="astatus">
                    <span className={`status-tag ${w.status}`}>{LABEL_STATUT[w.status]}</span>
                  </div>

                  <div className="actions">
                    {w.status === 'publie' ? (
                      <button className="btn ghost sm" disabled={busy} onClick={() => depublier(w)}>Dépublier</button>
                    ) : (
                      <button className="btn solid sm" disabled={busy} onClick={() => publier(w)}>Publier</button>
                    )}
                    <button className="btn ghost sm" onClick={() => setEditing(w)}>Modifier</button>
                    <details className="rowmenu">
                      <summary title="Plus d'actions">⋯</summary>
                      <div className="rowmenu-pop">
                        {w.status !== 'vendu' && (
                          <button type="button" onClick={e => { fermerMenu(e); vendre(w); }}>Marquer vendue</button>
                        )}
                        <button type="button" onClick={e => { fermerMenu(e); dupliquer(w); }}>Dupliquer en brouillon</button>
                        {w.status !== 'brouillon' && (
                          <a href={`/produit/?id=${w.slug}`} target="_blank" rel="noreferrer">Voir la fiche publique</a>
                        )}
                        <button type="button" className="danger" onClick={e => { fermerMenu(e); supprimer(w); }}>Supprimer</button>
                      </div>
                    </details>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {choisies.length > 0 && (
        <div className="bulkbar">
          <span className="bcount">{choisies.length} sélectionnée{choisies.length > 1 ? 's' : ''}</span>
          <button className="btn solid sm" disabled={busy} onClick={groupePublier}>Publier</button>
          <button className="btn ghost sm" disabled={busy} onClick={groupeDepublier}>En brouillon</button>
          <button className="btn ghost sm danger" disabled={busy} onClick={groupeSupprimer}>Supprimer</button>
          <button className="btn ghost sm" onClick={() => setSelected([])}>Annuler</button>
        </div>
      )}

      {toast && <div className="toast" onClick={() => setToast(null)}>{toast}</div>}
    </div>
  );
}

export default function Admin() {
  const [state, setState] = useState('chargement'); // chargement | non-connecte | non-admin | admin
  const [email, setEmail] = useState(null);

  useEffect(() => {
    let sub;
    (async () => {
      const session = await getSession();
      await handleSession(session);
      sub = onAuthChange(handleSession);
    })();
    return () => sub?.unsubscribe();
  }, []);

  async function handleSession(session) {
    if (!session) { setState('non-connecte'); return; }
    const em = session.user.email;
    setEmail(em);
    const admin = await checkIsAdmin(em);
    setState(admin ? 'admin' : 'non-admin');
  }

  if (state === 'chargement') return <div className="wrap"><p className="empty">Chargement…</p></div>;
  if (state === 'non-connecte') return <Login />;
  if (state === 'non-admin') {
    return (
      <div className="wrap" style={{ padding: '60px 0' }}>
        <h1>Accès non autorisé</h1>
        <p>Le compte {email} n'a pas les droits admin sur ce site. Ajoute son e-mail dans la table <code>admins</code> sur Supabase.</p>
        <button className="btn ghost" onClick={() => signOut()}>Déconnexion</button>
      </div>
    );
  }
  return <Dashboard email={email} />;
}
