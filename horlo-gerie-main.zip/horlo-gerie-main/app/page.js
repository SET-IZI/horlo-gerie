'use client';
import { useEffect, useState } from 'react';
import { getWatches } from '../lib/supabase';
import { BRAND_TILES, isVintage } from '../lib/site-data';
import WatchCard from '../components/WatchCard';
import Track from '../components/Track';

export default function Home() {
  const [watches, setWatches] = useState(null);
  useEffect(() => { getWatches().then(setWatches); }, []);

  const liste = watches || [];
  const nouveautes = liste.slice(0, 4);

  return (
    <>
      {/* ══════════ HERO ══════════ */}
      <section className="cover">
        <img src="/img/hero.jpg" alt="Omega Speedmaster Professional posée sur un tissu gris" width="1600" height="1067" />
        <div className="cover-in wrap">
          <span className="cover-brand">Horlo-Gerie</span>
          <span className="cover-est">
            Dépôt-vente de montres de collection — Paris · Lille · Bruxelles{' '}
            <span style={{ opacity: .62 }}>· Londres bientôt</span>
          </span>
          <h1>Des montres d’occasion, <em>contrôlées une à une.</em></h1>
          <p>Chaque pièce est ouverte, mesurée sur banc, révisée si nécessaire, puis décrite avec les mots exacts de l’horlogerie — avant de rejoindre la collection.</p>
          <div className="cta">
            <a className="btn light" href="/boutique/">Découvrir nos montres</a>
            <a className="btn onink" href="/#depot">Vendre votre montre</a>
          </div>
        </div>
      </section>

      {/* ══════════ GARANTIES ══════════ */}
      <div className="assur">
        <div className="wrap">
          <div><b>Authentification systématique</b><span>Calibre, gravures et numéros de série vérifiés.</span></div>
          <div><b>Contrôle sur banc</b><span>Marche, amplitude et étanchéité mesurées.</span></div>
          <div><b>Conservées en coffre</b><span>Expédition sous 48 h ouvrées, selon l’ouverture du coffre.</span></div>
          <div><b>7 jours pour inspecter</b><span>Vérifiez la montre en main dès réception.</span></div>
        </div>
      </div>

      {/* ══════════ NOUVEAUTÉS ══════════ */}
      <div className="sec">
        <div className="wrap">
          <div className="sec-head">
            <div><span className="eyebrow">Sélection</span><h2>Nouveautés de la semaine</h2></div>
            <div className="r"><p>Les dernières pièces sorties de l’atelier, toutes disponibles.</p></div>
          </div>
          {watches === null ? (
            <p className="empty">Chargement…</p>
          ) : nouveautes.length ? (
            <div className="grid-4">{nouveautes.map(w => <WatchCard key={w.id} w={w} />)}</div>
          ) : (
            <div className="empty-state">
              <p>Aucune pièce publiée pour l’instant. Ajoutez vos montres depuis l’espace d’administration.</p>
              <a className="btn ghost" href="/admin/">Ouvrir l’administration</a>
            </div>
          )}
          {liste.length > 4 && (
            <div className="sec-foot">
              <a className="btn ghost" href="/boutique/">Voir les {liste.length} pièces</a>
            </div>
          )}
        </div>
      </div>

      {/* ══════════ CHEMIN DE FER ══════════ */}
      {liste.length > 0 && (
        <div className="rail-sec" id="frise">
          <div className="wrap">
            <div className="rail-head">
              <div><span className="eyebrow">Chemin de fer</span><h2>La collection, dans l’ordre du temps.</h2></div>
              <p>Chaque montre est placée à son année de fabrication. Survolez une pièce pour la voir, cliquez une décennie pour filtrer la collection.</p>
            </div>
            <Track
              watches={liste}
              onDecade={d => { window.location.href = `/boutique/?decade=${d}`; }}
            />
          </div>
        </div>
      )}

      {/* ══════════ PAR MAISON ══════════ */}
      <div className="sec" id="maisons">
        <div className="wrap">
          <div className="sec-head">
            <div><span className="eyebrow">Marques</span><h2>Par maison</h2></div>
            <div className="r"><p>Peu de marques, choisies pour leur tenue dans le temps — au poignet comme à la revente.</p></div>
          </div>

          <div className="grid-3">
            {BRAND_TILES.map(b => {
              const n = liste.filter(w => b.key === 'vintage' ? isVintage(w) : w.marque === b.key).length;
              return (
                <a key={b.key} className="maison-tile" href={`/boutique/?brand=${encodeURIComponent(b.key)}`}>
                  <img src={`/img/${b.img}.jpg`} alt="" loading="lazy" />
                  <span className="in">
                    <span className="nm">{b.label}</span>
                    <span className="sub">
                      <span className="cue">{b.cue}</span>
                      <span className="ct">{n} pièce{n > 1 ? 's' : ''}</span>
                    </span>
                  </span>
                </a>
              );
            })}
            <a className="maison-tile more" href="/marques/">
              <span className="nm">Découvrir plus</span>
              <p>Toutes les maisons que nous prenons en dépôt, et notre espace dédié aux micro-marques haut de gamme.</p>
              <span className="go">Voir toutes les marques</span>
            </a>
          </div>

          {/* ══════════ RECHERCHE PERSONNALISÉE ══════════ */}
          <div className="search-box" id="recherche">
            <div>
              <span className="eyebrow">Recherche personnalisée</span>
              <h3>Vous cherchez une pièce précise ?</h3>
              <p>Donnez-nous la référence, l’année et le budget. Nous interrogeons nos déposants et nos confrères, et nous vous écrivons dès qu’une montre correspond — avec son rapport de contrôle, comme les autres.</p>
            </div>
            <div className="side">
              <a className="btn" href="mailto:contact@horlo-gerie.fr?subject=Recherche%20personnalis%C3%A9e">Décrire ma recherche</a>
              <p className="fine">Réponse sous 48 h. Aucun frais tant que la pièce n’est pas trouvée et acceptée.</p>
            </div>
          </div>
        </div>
      </div>

      {/* ══════════ NOTRE CONTRÔLE ══════════ */}
      <div className="sec alt" id="controle">
        <div className="wrap">
          <div className="sec-head">
            <div><span className="eyebrow">Notre contrôle</span><h2>Ce que nous faisons avant de vous la confier</h2></div>
            <div className="r"><p>Une montre d’occasion n’a pas à être une montre incertaine. Trois étapes, dans cet ordre, pour chaque pièce — sans exception.</p></div>
          </div>
          <div className="steps">
            <div className="step">
              <div className="n">Étape I</div>
              <h3>Ouverture &amp; authentification</h3>
              <p>Boîte, fond, couronne, calibre : chaque composant est comparé aux références de la manufacture. Les numéros de série sont relevés et vérifiés. Une pièce non conforme n’entre pas.</p>
              <div className="kw">Gravures · calibre · numéros de série</div>
            </div>
            <div className="step">
              <div className="n">Étape II</div>
              <h3>Contrôle sur banc &amp; révision</h3>
              <p>Marche, amplitude, réserve de marche et étanchéité sont mesurées. Si les valeurs sortent des tolérances, la montre part en révision chez un horloger avant d’être proposée.</p>
              <div className="kw">Amplitude · marche · étanchéité</div>
            </div>
            <div className="step">
              <div className="n">Étape III</div>
              <h3>Remise, inspection &amp; garantie</h3>
              <p>Chaque montre est livrée avec son rapport de contrôle et la liste exacte de ses accessoires — boîte, papiers, maillons. Vous disposez de 7 jours pour l’inspecter en main, et de la garantie légale de conformité pendant deux ans.</p>
              <div className="kw">Rapport · accessoires · 7 jours d’inspection</div>
            </div>
          </div>
        </div>
      </div>

      {/* ══════════ DÉPÔT ══════════ */}
      <div className="ink" id="depot">
        <div className="wrap">
          <div>
            <span className="eyebrow">Déposer une montre</span>
            <h2>Vous fixez le prix.<br /><em>Nous faisons le reste.</em></h2>
            <p>Vous confiez la montre, nous la contrôlons, la photographions, la présentons et la vendons. Vous restez propriétaire jusqu’à la vente ; la commission est annoncée par écrit avant la mise en ligne, jamais après.</p>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <a className="btn onink" href="mailto:contact@horlo-gerie.fr?subject=D%C3%A9p%C3%B4t%20d%27une%20montre">Proposer une montre</a>
              <a className="btn onink" href="/vendues/">Voir nos ventes réalisées</a>
            </div>
            <div className="ink-facts">
              <div><b>3 villes</b><span>Estimation en main à Paris, Lille ou Bruxelles — Londres bientôt.</span></div>
              <div><b>En coffre</b><span>Pièce assurée et gardée en coffre pendant tout le dépôt.</span></div>
              <div><b>7 jours</b><span>Virement après la vente.</span></div>
            </div>
          </div>
          <div className="ink-img"><img src="/img/mouvement-or.jpg" alt="Mouvement mécanique vu de près" loading="lazy" /></div>
        </div>
      </div>

      {/* ══════════ LA MAISON ══════════ */}
      <div className="sec pledge" id="maison">
        <div className="wrap">
          <div className="ph"><img src="/img/atelier-mains.jpg" alt="Horloger au travail sur un mouvement" /></div>
          <div>
            <span className="eyebrow">La maison</span>
            <div className="q" style={{ marginTop: 16 }}>
              <p>Horlo-Gerie est un dépôt-vente, pas une place de marché. Chaque montre passe entre nos mains avant d’apparaître ici — c’est plus lent, et c’est exactement le point.</p>
              <p>Nous décrivons les pièces avec les mots exacts de l’horlogerie : <em>full set</em> quand tout y est, <em>papiers seuls</em> quand c’est le cas, <em>révisée</em> avec la date. Pas d’adjectifs, des faits.</p>
            </div>
            <div className="sig smallcaps">Mathéo — fondateur</div>
          </div>
        </div>
      </div>
    </>
  );
}
