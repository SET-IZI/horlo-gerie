# Horlo-Gerie — le vrai site (Next.js + Supabase)

Ceci est la V1 du **vrai site**, branché sur une vraie base de données, à
la différence du prototype HTML (`~/Claude/Projects/HORLO-GERIE/`) qui
simulait tout dans le navigateur.

## Comment ça marche, pensé pour LWS + FileZilla

Le site est configuré en **export statique** (`next.config.js` →
`output: 'export'`). Ça veut dire :

- `npm run build` fabrique un dossier `out/` fait uniquement de fichiers
  HTML/CSS/JS — pas de serveur Node nécessaire pour l'héberger.
- Tu envoies ensuite le contenu de `out/` par FileZilla dans le dossier
  web de ton hébergement LWS (souvent `www/` ou le dossier racine du
  domaine horlo-gerie.com).
- **Les fiches, la collection et les ventes réalisées se chargent en
  direct depuis Supabase à chaque visite** (pas au moment du build) :
  donc quand tu ajoutes une montre dans Supabase, elle apparaît sur le
  site sans avoir besoin de relancer `npm run build` ni de refaire un
  transfert FileZilla. Tu n'as besoin de rebuilder + réenvoyer que
  quand tu changes le **design ou le code** du site.

## Mise en route

### 1. Créer le projet Supabase
1. Va sur [supabase.com](https://supabase.com), crée un projet (gratuit pour démarrer).
2. Dans l'éditeur SQL du projet, exécute `sql/schema.sql` puis `sql/seed.sql`
   (le seed reprend les 14 pièces et les 12 ventes du prototype, à titre
   d'exemple — remplace-les par ton vrai stock quand tu veux).
3. Dans *Project Settings → API*, récupère l'URL du projet et la clé
   `anon public`.

### 2. Configurer le site
```
cp .env.local.example .env.local
```
Colle l'URL et la clé Supabase dans `.env.local`.

### 3. Tester en local
```
npm install
npm run dev
```
Le site est visible sur http://localhost:3000

### 4. Construire pour l'envoi FTP
```
npm run build
```
Le dossier `out/` est prêt à être envoyé tel quel par FileZilla vers
l'hébergement LWS du domaine horlo-gerie.com.

## Ce qui est fait dans cette V1

- Page d'accueil, boutique (catalogue), fiche produit, page marques,
  ventes réalisées, conditions générales de vente — toutes reliées à
  la vraie base Supabase (sauf marques, statique) et au vrai design
  (palette crème/encre/or, polices Jost + Manrope).
- Prix, état, calibre, accessoires, référence : tous les champs du
  prototype existent dans la table `watches`.

## Ce qui reste à faire (phase 2, pas encore branché)

- **Photos réelles** : pour l'instant les fiches affichent un
  placeholder tant que la colonne `photos` est vide. Il faut activer
  Supabase Storage (un bucket `photos`), y déposer tes vraies photos,
  et coller leurs URLs dans la colonne `photos` de chaque montre.
- **Espace admin** (ajouter/éditer une annonce, glisser-déposer des
  photos, marquer une pièce vendue) — dans le prototype c'était simulé
  en local ; il faut une vraie page protégée par l'authentification
  Supabase.
- **Compte client** (favoris, tchat) — nécessite Supabase Auth (lien
  magique par e-mail) + une table `favoris` et une table `messages`.
- **Chemin de fer / timeline horlogère** de la page d'accueil du
  prototype — pas encore repris ici, à ajouter une fois le contenu
  réel en place.
- Liens Shopify (`checkout_url` par montre), profil Chrono24, newsletter
  Brevo : champs prévus mais pas encore remplis.

## Fichiers
- `app/` — les pages (routeur App Router de Next.js)
- `lib/supabase.js` — connexion et requêtes Supabase
- `sql/schema.sql`, `sql/seed.sql` — base de données
- `styles/globals.css` — le design (charte Horlo-Gerie)
