'use client';
import { C24_URL } from '../lib/site-data';

// Lien vers le profil Chrono24 : actif dès que C24_URL est renseignée dans
// lib/site-data.js, badge « Bientôt » tant qu'elle est vide.
export default function C24Link() {
  if (!C24_URL.trim()) {
    return <span className="c24" aria-disabled="true">Chrono24 <span className="soon">Bientôt</span></span>;
  }
  return (
    <a className="c24" href={C24_URL} target="_blank" rel="noopener noreferrer">Notre profil Chrono24</a>
  );
}
