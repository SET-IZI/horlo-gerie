'use client';
import { useMemo, useRef, useState } from 'react';
import { eur, watchPhoto } from '../lib/supabase';

// Le « chemin de fer » : chaque montre est placée à son année de fabrication.
// Survol d'une pièce = aperçu ; clic = fiche ; clic sur une décennie = filtre.
const W = 1200, H = 96, BASE = 58, ML = 18, MR = 18;

export default function Track({ watches, activeDecade = null, onDecade }) {
  const svgRef = useRef(null);
  const [aig, setAig] = useState(null);      // position de l'aiguille de survol
  const [peek, setPeek] = useState(null);    // aperçu de la pièce survolée

  const { Y0, Y1, points, decades } = useMemo(() => {
    const annees = (watches || []).map(w => w.annee).filter(Boolean);
    const now = new Date().getFullYear();
    const min = annees.length ? Math.min(...annees) : 1960;
    const y0 = Math.min(1960, Math.floor(min / 10) * 10);
    const y1 = now;
    const x = y => ML + (y - y0) / (y1 - y0) * (W - ML - MR);

    const vus = {};
    const pts = (watches || []).filter(w => w.annee).map(w => {
      vus[w.annee] = (vus[w.annee] || 0) + 1;
      const lift = 17 + (vus[w.annee] - 1) * 12;
      return { w, cx: x(w.annee), cy: BASE - lift };
    });

    const decs = [];
    for (let d = Math.floor(y0 / 10) * 10; d < y1 + 10; d += 10) {
      const a = x(Math.max(d, y0)), b = x(Math.min(d + 10, y1));
      if (b > a) decs.push({ d, a, w: b - a });
    }
    return { Y0: y0, Y1: y1, points: pts, decades: decs };
  }, [watches]);

  const xOf = y => ML + (y - Y0) / (Y1 - Y0) * (W - ML - MR);

  const ticks = [];
  for (let y = Y0; y <= Y1; y++) {
    const major = y % 10 === 0, mid = y % 5 === 0;
    ticks.push({ y, major, mid, h: major ? 15 : (mid ? 9 : 4.5) });
  }

  function handleMove(e) {
    const r = svgRef.current.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width * W;
    const year = Math.round(Y0 + (px - ML) / (W - ML - MR) * (Y1 - Y0));
    if (year < Y0 || year > Y1) return;
    setAig({ px, year });
  }

  function ouvrir(w) {
    window.location.href = `/produit/?id=${encodeURIComponent(w.slug)}`;
  }

  return (
    <div className={`track${aig ? ' live' : ''}`}>
      <svg
        ref={svgRef} viewBox={`0 0 ${W} ${H}`} role="img"
        aria-label="Frise chronologique de la collection"
        onPointerMove={handleMove}
        onPointerLeave={() => { setAig(null); setPeek(null); }}
      >
        {decades.map(d => (
          <rect
            key={d.d} className={`decade${activeDecade === d.d ? ' active' : ''}`}
            x={d.a} y={BASE - 36} width={d.w} height={56}
            onClick={() => onDecade && onDecade(d.d)}
          />
        ))}

        <line className="rail" x1={ML} y1={BASE} x2={W - MR} y2={BASE} />

        {ticks.map(t => (
          <line key={t.y} className={`t ${t.major ? 'major' : (t.mid ? 'mid' : '')}`}
                x1={xOf(t.y)} y1={BASE} x2={xOf(t.y)} y2={BASE + t.h} />
        ))}
        {ticks.filter(t => t.major).map(t => (
          <text key={`y${t.y}`} className="yr" x={xOf(t.y)} y={BASE + 31} textAnchor="middle">{t.y}</text>
        ))}

        {points.map(p => (
          <g
            key={p.w.id} className={`piece${peek && peek.w.id === p.w.id ? ' on' : ''}`}
            tabIndex={0} role="button" aria-label={`${p.w.marque} ${p.w.modele}, ${p.w.annee}`}
            onPointerEnter={() => setPeek(p)}
            onFocus={() => setPeek(p)}
            onBlur={() => setPeek(null)}
            onClick={e => { e.stopPropagation(); ouvrir(p.w); }}
            onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); ouvrir(p.w); } }}
          >
            <line className="stem" x1={p.cx} y1={BASE} x2={p.cx} y2={p.cy} />
            <circle cx={p.cx} cy={p.cy} r={4.2} />
          </g>
        ))}

        {aig && <>
          <line className="aig" x1={aig.px} y1={BASE - 42} x2={aig.px} y2={BASE + 19} />
          <text className="aig-yr" x={aig.px} y={BASE - 48} textAnchor="middle">{aig.year}</text>
        </>}
      </svg>

      <div className={`peek${peek ? ' on' : ''}`} style={peek ? { left: `${Math.min(92, Math.max(8, peek.cx / W * 100))}%` } : undefined}>
        <div className="ph"><img src={peek ? watchPhoto(peek.w) : ''} alt="" /></div>
        <div className="c">
          <div className="smallcaps">{peek ? `${peek.w.marque} · ${peek.w.annee}` : ''}</div>
          <div className="m">{peek ? peek.w.modele : ''}</div>
          <div className="p">{peek ? eur(peek.w.prix) : ''}</div>
        </div>
      </div>
    </div>
  );
}
