'use client';
import { useEffect, useState } from 'react';
import {
  supabase, sendMagicLink, signOut, getSession, onAuthChange,
  getMyClientProfile, saveMyClientProfile, getMyFavoriteIds, toggleFavorite, eur, watchPhoto,
} from '../../lib/supabase';
import WatchCard from '../../components/WatchCard';

function Login() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setErr('');
    const { error } = await sendMagicLink(email);
    if (error) setErr(error.message); else setSent(true);
  }

  return (
    <div className="wrap" style={{ paddingBlock: 'clamp(40px,6vw,90px)', maxWidth: 460 }}>
      <span className="eyebrow">Espace client</span>
      <h1 style={{ fontSize: 'clamp(28px,3.4vw,42px)', marginTop: 14 }}>Connexion</h1>
      {sent ? (
        <p style={{ marginTop: 18, color: 'var(--steel-text)' }}>
          Un lien de connexion a été envoyé à <b style={{ color: 'var(--ink)' }}>{email}</b>.
          Ouvrez-le depuis cet appareil pour vous connecter.
        </p>
      ) : (
        <form onSubmit={handleSubmit} className="watch-form" style={{ marginTop: 18 }}>
          <p style={{ margin: '0 0 18px', color: 'var(--steel-text)', fontSize: 15, lineHeight: 1.6 }}>
            Sans mot de passe : vous recevez un lien par e-mail. Votre compte garde vos favoris et
            votre conversation avec nous, d’un appareil à l’autre.
          </p>
          <label className="block">Votre adresse e-mail
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="vous@exemple.fr" />
          </label>
          {err && <p className="err">{err}</p>}
          <button className="btn" style={{ marginTop: 16, width: '100%' }}>Recevoir le lien de connexion</button>
        </form>
      )}
    </div>
  );
}

function Dashboard({ email }) {
  const [nom, setNom] = useState('');
  const [tel, setTel] = useState('');
  const [saved, setSaved] = useState(false);
  const [favs, setFavs] = useState(null);

  useEffect(() => {
    getMyClientProfile().then(p => { setNom((p && p.nom) || ''); setTel((p && p.telephone) || ''); });
    chargerFavoris();
  }, []);

  async function chargerFavoris() {
    const ids = await getMyFavoriteIds();
    if (!ids.length) { setFavs([]); return; }
    const { data } = await supabase.from('watches').select('*').in('id', ids);
    setFavs(data || []);
  }

  async function enregistrer(e) {
    e.preventDefault();
    await saveMyClientProfile({ nom, telephone: tel });
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
  }

  return (
    <div className="wrap account" style={{ paddingBlock: 'clamp(26px,3.2vw,48px) clamp(60px,7vw,100px)' }}>
      <div className="account-top">
        <div>
          <span className="eyebrow">Espace client</span>
          <h1>Mes favoris</h1>
          <div className="who">{nom ? `${nom} · ${email}` : email}</div>
        </div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <a className="btn ghost" href="/boutique/">Voir la collection</a>
          <button className="btn ghost" onClick={() => signOut()}>Se déconnecter</button>
        </div>
      </div>

      <form onSubmit={enregistrer} className="watch-form" style={{ marginTop: 'clamp(24px,3vw,38px)', maxWidth: 620 }}>
        <div className="fgrid" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <label>Nom<input value={nom} onChange={e => setNom(e.target.value)} /></label>
          <label>Téléphone <span style={{ fontWeight: 400 }}>(facultatif, si vous souhaitez être recontacté)</span>
            <input value={tel} onChange={e => setTel(e.target.value)} />
          </label>
        </div>
        <button className="btn ghost sm">{saved ? 'Enregistré ✓' : 'Enregistrer'}</button>
      </form>

      <div style={{ marginTop: 'clamp(26px,3vw,42px)' }}>
        {favs === null ? (
          <p className="empty">Chargement…</p>
        ) : favs.length === 0 ? (
          <div className="empty-state">
            <p>Aucun favori pour l’instant — touchez le cœur sur une montre pour la retrouver ici.</p>
            <a className="btn ghost" href="/boutique/">Parcourir la collection</a>
          </div>
        ) : (
          <div className="grid-4">{favs.map(w => <WatchCard key={w.id} w={w} />)}</div>
        )}
      </div>

      <div className="search-box" style={{ marginTop: 'clamp(32px,4vw,56px)' }}>
        <div>
          <span className="eyebrow">Une question ?</span>
          <h3>Nous sommes joignables ici</h3>
          <p>Ouvrez la discussion en bas à droite de l’écran : vos messages nous arrivent directement, et vous retrouverez la conversation à chaque visite, même depuis un autre appareil.</p>
        </div>
        <div className="side">
          <a className="btn" href="mailto:contact@horlo-gerie.fr">Nous écrire</a>
          <p className="fine">Réponse sous 48 h par e-mail, en général sous 10 minutes par la discussion.</p>
        </div>
      </div>
    </div>
  );
}

export default function Compte() {
  const [state, setState] = useState('chargement');
  const [email, setEmail] = useState(null);

  useEffect(() => {
    let sub;
    (async () => {
      apply(await getSession());
      sub = onAuthChange(apply);
    })();
    return () => sub?.unsubscribe();
  }, []);

  function apply(session) {
    setEmail(session && session.user ? session.user.email : null);
    setState(session ? 'connecte' : 'non-connecte');
  }

  if (state === 'chargement') return <div className="wrap"><p className="empty">Chargement…</p></div>;
  if (state === 'non-connecte') return <Login />;
  return <Dashboard email={email} />;
}
