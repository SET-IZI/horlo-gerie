-- ═══════════ TCHAT ═══════════
-- Une conversation par client. Le visiteur doit être connecté (lien magique)
-- pour écrire : c'est ce qui permet de lui répondre après son départ du site.

create table if not exists messages (
  id bigint generated always as identity primary key,
  client_id uuid not null references clients(id) on delete cascade,
  auteur text not null check (auteur in ('client', 'admin')),
  texte text not null,
  lu boolean not null default false,     -- lu par le destinataire
  created_at timestamptz not null default now()
);

create index if not exists messages_client_idx on messages(client_id, created_at);

alter table messages enable row level security;

-- Le client lit sa conversation et n'écrit que sous son propre nom
create policy "Un client lit sa conversation"
  on messages for select
  using (auth.uid() = client_id);

create policy "Un client écrit dans sa conversation"
  on messages for insert
  with check (auth.uid() = client_id and auteur = 'client');

-- Le client peut marquer comme lus les messages qui lui sont adressés
create policy "Un client marque ses messages comme lus"
  on messages for update
  using (auth.uid() = client_id)
  with check (auth.uid() = client_id);

-- Les admins voient et gèrent toutes les conversations
create policy "Les admins gèrent toutes les conversations"
  on messages for all
  using ((auth.jwt() ->> 'email') in (select email from admins))
  with check ((auth.jwt() ->> 'email') in (select email from admins));

-- ═══════════ NEWSLETTER ═══════════
-- Inscriptions à la lettre des nouvelles pièces. À synchroniser avec Brevo
-- (le même outil que pour MJ Services) quand la clé API sera en place.

create table if not exists newsletter (
  email text primary key,
  created_at timestamptz not null default now(),
  source text default 'site'
);

alter table newsletter enable row level security;

-- N'importe qui peut s'inscrire, personne ne peut lire la liste sauf les admins
create policy "Inscription ouverte à la newsletter"
  on newsletter for insert
  with check (true);

create policy "Les admins lisent les inscrits"
  on newsletter for select
  using ((auth.jwt() ->> 'email') in (select email from admins));
