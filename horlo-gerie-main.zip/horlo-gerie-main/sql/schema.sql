-- Schéma Supabase pour Horlo-Gerie
-- À exécuter dans l'éditeur SQL de ton projet Supabase (supabase.com/dashboard → SQL Editor)

create extension if not exists pgcrypto;

create table if not exists watches (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,              -- utilisé dans l'URL de la fiche produit
  marque text not null,
  modele text not null,
  ref text,                               -- référence du modèle
  annee int,                              -- année de fabrication (affichage "environ X ans")
  date_prod date,                         -- date précise si connue (carte de garantie, poinçon...)
  date_source text,                       -- d'où vient date_prod : "carte de garantie", "poinçon", "facture"
  prix numeric not null,
  etat text,                              -- Bon / Très bon / Excellent / État neuf
  acc text,                               -- 'full' | 'papiers' | 'aucun'
  calibre text,
  diam text,
  revision text,                          -- ex. "Révisée 03/2026"
  description text,
  photos text[] default '{}',             -- URLs de photos (Supabase Storage), la première = photo principale
  checkout_url text,                      -- lien de paiement Shopify pour cette pièce
  status text not null default 'brouillon' check (status in ('brouillon','publie','vendu')),
  vendu_prix numeric,                     -- prix de vente réel si status = 'vendu'
  vendu_le date,                          -- mois/date de vente
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists watches_status_idx on watches(status);
create index if not exists watches_marque_idx on watches(marque);

-- Lecture publique : uniquement ce qui est publié ou vendu (le brouillon reste privé)
alter table watches enable row level security;

create policy "Public : pièces publiées et vendues visibles"
  on watches for select
  using (status in ('publie', 'vendu'));

-- ═══════════ ESPACE ADMIN ═══════════
-- Liste des e-mails autorisés à gérer les annonces (connexion par lien magique
-- Supabase Auth — pas de mot de passe). Ajoute tes adresses ici :
--   insert into admins (email) values ('toi@horlo-gerie.fr');

create table if not exists admins (
  email text primary key
);

alter table admins enable row level security;

create policy "Chacun peut vérifier son propre statut admin"
  on admins for select
  using (auth.jwt() ->> 'email' = email);

-- Un admin authentifié peut tout voir (y compris les brouillons) et tout modifier
create policy "Les admins gèrent toutes les montres"
  on watches for all
  using ((auth.jwt() ->> 'email') in (select email from admins))
  with check ((auth.jwt() ->> 'email') in (select email from admins));

-- ═══════════ STOCKAGE DES PHOTOS ═══════════
insert into storage.buckets (id, name, public)
values ('photos', 'photos', true)
on conflict (id) do nothing;

create policy "Lecture publique des photos"
  on storage.objects for select
  using (bucket_id = 'photos');

create policy "Les admins ajoutent des photos"
  on storage.objects for insert
  with check (bucket_id = 'photos' and (auth.jwt() ->> 'email') in (select email from admins));

create policy "Les admins suppriment des photos"
  on storage.objects for delete
  using (bucket_id = 'photos' and (auth.jwt() ->> 'email') in (select email from admins));

-- ═══════════ COMPTES CLIENTS ═══════════
-- Une fiche est créée automatiquement à la première connexion (lien magique).
-- Le téléphone est facultatif : uniquement s'il souhaite être recontacté.

create table if not exists clients (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  nom text,
  telephone text,
  created_at timestamptz default now()
);

alter table clients enable row level security;

create policy "Un client gère sa propre fiche"
  on clients for all
  using (auth.uid() = id)
  with check (auth.uid() = id);

create policy "Les admins consultent toutes les fiches clients"
  on clients for select
  using ((auth.jwt() ->> 'email') in (select email from admins));

-- Crée automatiquement la fiche client à la première connexion
create or replace function public.handle_new_client()
returns trigger as $$
begin
  insert into public.clients (id, email) values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer set search_path = public;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_client();

-- ═══════════ FAVORIS ═══════════
create table if not exists favoris (
  client_id uuid references clients(id) on delete cascade,
  watch_id uuid references watches(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (client_id, watch_id)
);

alter table favoris enable row level security;

create policy "Un client gère ses propres favoris"
  on favoris for all
  using (auth.uid() = client_id)
  with check (auth.uid() = client_id);

create policy "Les admins consultent tous les favoris"
  on favoris for select
  using ((auth.jwt() ->> 'email') in (select email from admins));

-- ═══════════ COMMANDES ═══════════
-- Historique des ventes rattachées à un client, saisi depuis l'admin quand
-- une pièce passe au statut "vendu" (pas de webhook Shopify branché pour l'instant).
create table if not exists commandes (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references clients(id) on delete set null,
  watch_id uuid references watches(id) on delete set null,
  prix numeric,
  date date default current_date,
  created_at timestamptz default now()
);

alter table commandes enable row level security;

create policy "Un client voit ses propres commandes"
  on commandes for select
  using (auth.uid() = client_id);

create policy "Les admins gèrent toutes les commandes"
  on commandes for all
  using ((auth.jwt() ->> 'email') in (select email from admins))
  with check ((auth.jwt() ->> 'email') in (select email from admins));

-- ═══════════ PAGES VISITÉES ═══════════
-- Historique des pages vues, pour les clients connectés (client_id renseigné)
-- et pour les visiteurs anonymes (client_id vide, seule l'IP est connue).
-- ⚠️ À mentionner explicitement dans les CGV (article Données personnelles) —
-- l'IP est une donnée personnelle. Aucun rapprochement automatique entre une
-- IP anonyme et un client identifié n'est fait ici (volontairement).
create table if not exists visites (
  id bigint generated always as identity primary key,
  client_id uuid references clients(id) on delete cascade,
  ip text,
  user_agent text,
  chemin text,
  created_at timestamptz default now()
);

create index if not exists visites_client_idx on visites(client_id, created_at desc);
create index if not exists visites_ip_idx on visites(ip, created_at desc);

alter table visites enable row level security;

create policy "Un client enregistre ses propres visites"
  on visites for insert
  with check (auth.uid() = client_id);

create policy "Les visiteurs anonymes peuvent aussi être journalisés"
  on visites for insert
  with check (client_id is null);

create policy "Les admins consultent toutes les visites"
  on visites for select
  using ((auth.jwt() ->> 'email') in (select email from admins));
