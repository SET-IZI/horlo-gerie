export const metadata = { title: 'Conditions générales de vente — Horlo-Gerie' };

export default function Conditions() {
  return (
    <div className="wrap legal" style={{ padding: '32px 0' }}>
      <div style={{ maxWidth: '52em' }}>
        <span className="eyebrow">Document contractuel</span>
        <h1>Conditions générales de vente</h1>
        <p>Ces conditions régissent toute vente de montre conclue à distance sur horlo-gerie.fr, ainsi que les dépôts confiés à Horlo-Gerie. Version du 12 septembre 2026.</p>
      </div>

      <div className="grid-legal" style={{ marginTop: 32 }}>
        <nav className="toc">
          {['Le vendeur','Objet','Les montres proposées','Prix et TVA sur marge','Commande et paiement','Livraison','Inspection à réception','Droit de rétractation','Garanties','Dépôt-vente','Responsabilité','Données personnelles','Droit applicable et litiges'].map((t, i) => (
            <a key={i} href={`#art-${i+1}`}>{i+1}. {t}</a>
          ))}
        </nav>

        <div>
          <div className="warn">
            <span className="m">!</span>
            <p><b>Projet à faire valider.</b> Ce texte met en forme les décisions commerciales prises pour Horlo-Gerie ; il n'a pas été relu par un juriste. L'article 8 en particulier doit être vérifié avant mise en ligne — voir la note qui l'accompagne. Les champs surlignés restent à compléter.</p>
          </div>

          <article className="art" id="art-1">
            <h2><span className="no">01</span>Le vendeur</h2>
            <p>Le site horlo-gerie.fr est édité par <span className="fill">raison sociale</span>, <span className="fill">forme juridique</span> au capital de <span className="fill">montant</span>, dont le siège est situé <span className="fill">adresse complète</span>, immatriculée au RCS de <span className="fill">ville</span> sous le numéro <span className="fill">SIREN</span>, numéro de TVA intracommunautaire <span className="fill">FR…</span>.</p>
            <p>Directeur de la publication : <span className="fill">nom</span>. Contact : contact@horlo-gerie.fr. Hébergeur : <span className="fill">nom et adresse de l'hébergeur</span>.</p>
          </article>

          <article className="art" id="art-2">
            <h2><span className="no">02</span>Objet</h2>
            <p>Les présentes conditions s'appliquent à toute commande de montre passée sur le site, sans réserve. Le fait de valider une commande vaut acceptation pleine et entière. Elles s'appliquent également, pour les articles qui les concernent, aux personnes qui confient une montre en dépôt-vente.</p>
          </article>

          <article className="art" id="art-3">
            <h2><span className="no">03</span>Les montres proposées</h2>
            <p>Toutes les montres vendues sont des <strong>montres d'occasion ou en état neuf</strong>, à l'exception de celles expressément présentées comme neuves. Chaque pièce est ouverte, authentifiée et contrôlée sur banc avant mise en vente ; le rapport de contrôle est remis avec la montre.</p>
            <p>La fiche de chaque montre indique son état, son calibre, son diamètre, la date de son dernier contrôle ou de sa dernière révision, et la liste exacte de ses accessoires : <strong>full set</strong> lorsque la boîte, les papiers et les maillons sont présents, <strong>papiers seuls</strong> ou <strong>sans boîte ni papiers</strong> le cas échéant.</p>
            <p>Les photographies publiées sont celles de la pièce réellement mise en vente. L'usure cosmétique propre à une montre d'occasion — micro-rayures, patine du cadran ou de la lunette, légère décoloration — fait partie de l'objet vendu et ne constitue pas un défaut de conformité.</p>
          </article>

          <article className="art" id="art-4">
            <h2><span className="no">04</span>Prix et TVA sur marge</h2>
            <p>Les prix sont indiqués en euros, toutes taxes comprises. Les montres d'occasion sont vendues sous le <strong>régime de la TVA sur la marge</strong> (article 297 A du Code général des impôts) : la TVA n'apparaît pas séparément sur la facture et n'est pas récupérable par l'acheteur.</p>
            <p>Les frais de livraison sont annoncés avant la validation de la commande. Horlo-Gerie se réserve le droit de modifier ses prix à tout moment, la montre étant facturée au tarif affiché au moment de la commande.</p>
          </article>

          <article className="art" id="art-5">
            <h2><span className="no">05</span>Commande et paiement</h2>
            <p>Chaque montre étant une pièce unique, elle est retirée de la vente dès qu'une commande est validée. Le paiement s'effectue en une fois, par lien de paiement sécurisé Shopify (carte bancaire) ou par virement bancaire pour les montants les plus élevés. Aucune coordonnée bancaire ne transite ni n'est conservée par Horlo-Gerie.</p>
            <p>La vente n'est définitive qu'après encaissement complet du prix. Horlo-Gerie se réserve le droit de refuser une commande en cas de litige antérieur, de suspicion de fraude, ou d'erreur manifeste d'affichage du prix.</p>
          </article>

          <article className="art" id="art-6">
            <h2><span className="no">06</span>Livraison</h2>
            <p>Les montres sont conservées en coffre. Elles sont expédiées <strong>sous 48 heures ouvrées après encaissement, sous réserve des heures d'ouverture du coffre</strong> : une commande validée en dehors de ces horaires est préparée à la première ouverture utile. L'envoi est assuré à hauteur du prix de vente, avec signature obligatoire à la remise.</p>
            <p>La livraison est possible en France et dans l'Union européenne. La remise en main propre est possible sur rendez-vous dans nos trois points d'accueil : Paris, Lille et Bruxelles. Le délai réel d'expédition est confirmé par courriel après la commande.</p>
            <p>Le transfert des risques intervient à la remise du colis. Toute avarie ou colis endommagé doit faire l'objet de réserves écrites auprès du transporteur au moment de la livraison, et nous être signalé le jour même.</p>
          </article>

          <article className="art" id="art-7">
            <h2><span className="no">07</span>Inspection à réception</h2>
            <p>L'acheteur dispose d'un <strong>délai de 7 jours calendaires à compter de la réception</strong> pour examiner la montre et vérifier sa conformité à la description : état, fonctionnement, accessoires annoncés. Une notice d'inspection accompagne chaque envoi.</p>
            <p>Toute réclamation relative à la conformité apparente doit être adressée par écrit à contact@horlo-gerie.fr dans ce délai, accompagnée de photographies. <strong>Passé ce délai, la montre est réputée acceptée en l'état</strong>, ce qui ne prive l'acheteur d'aucune des garanties légales prévues à l'article 9.</p>
          </article>

          <article className="art" id="art-8">
            <h2><span className="no">08</span>Droit de rétractation</h2>
            <p>Pour toute vente conclue à distance avec un consommateur, l'acheteur dispose d'un <strong>délai de quatorze jours calendaires</strong> à compter de la réception de la montre pour exercer son droit de rétractation, conformément aux articles L.221-18 et suivants du Code de la consommation. Aucun motif n'a à être donné.</p>
            <p>La rétractation s'exerce par une déclaration dénuée d'ambiguïté adressée à contact@horlo-gerie.fr avant l'expiration du délai. La montre doit ensuite être renvoyée <strong>dans les quatorze jours suivant cette déclaration</strong>, dans l'état où elle a été livrée, complète de ses accessoires, de sa boîte et de ses papiers lorsqu'ils ont été fournis. L'acheteur répond de la dépréciation résultant de manipulations autres que celles nécessaires pour établir la nature et les caractéristiques de la montre.</p>
            <p>Les frais de retour sont à la charge de l'acheteur, sauf mention contraire au moment de la commande. Le retour doit être effectué en envoi assuré pour la valeur de la montre. Le remboursement, comprenant les frais de livraison standard initialement facturés, intervient dans les <strong>quatorze jours suivant la réception de la montre retournée</strong>, ou la preuve de son expédition si elle est antérieure, par le même moyen de paiement que celui utilisé lors de l'achat.</p>
            <p>Le délai d'inspection de sept jours prévu à l'article 7 est distinct de ce droit et s'y ajoute : il porte sur la conformité de la montre à sa description, et non sur la convenance de l'acheteur. Les ventes conclues en main propre à Paris, Lille ou Bruxelles ne constituent pas des ventes à distance et ne relèvent donc pas de ce droit de rétractation.</p>
          </article>

          <article className="art" id="art-9">
            <h2><span className="no">09</span>Garanties</h2>
            <p>Indépendamment de toute garantie commerciale, l'acheteur bénéficie de la <strong>garantie légale de conformité</strong> (articles L.217-3 et suivants du Code de la consommation) et de la <strong>garantie légale contre les vices cachés</strong> (articles 1641 et suivants du Code civil). Pour un bien d'occasion, la garantie de conformité s'exerce pendant <strong>deux ans</strong> à compter de la délivrance, le défaut étant présumé exister au jour de la délivrance pendant les douze premiers mois.</p>
            <p>Ne relèvent pas de ces garanties, s'agissant de montres d'occasion :</p>
            <ul>
              <li>l'usure cosmétique décrite dans la fiche produit et visible sur les photographies ;</li>
              <li>les dommages postérieurs à la livraison : chocs, immersion, exposition à un champ magnétique, mauvaise manipulation de la couronne ou des poussoirs ;</li>
              <li>les organes d'usure courante — bracelet, joints, verre, lume ;</li>
              <li>l'étanchéité, qui ne peut être garantie dans la durée sur une montre ancienne et doit être recontrôlée périodiquement ;</li>
              <li>toute intervention réalisée en dehors de nos ateliers ou du réseau officiel de la marque.</li>
            </ul>
            <p>La mise en œuvre d'une garantie se fait par écrit à contact@horlo-gerie.fr, avec description du défaut et photographies. La montre est expertisée avant toute décision de réparation, de remplacement ou de remboursement.</p>
          </article>

          <article className="art" id="art-10">
            <h2><span className="no">10</span>Dépôt-vente</h2>
            <p>Le déposant reste propriétaire de sa montre jusqu'à la vente. Un mandat de dépôt écrit précise le prix de vente convenu, la commission d'Horlo-Gerie, la durée du dépôt et les conditions de restitution. La commission est annoncée avant la mise en ligne et n'est jamais modifiée en cours de mandat.</p>
            <p>La montre déposée est conservée en coffre et couverte par notre assurance pendant toute la durée du dépôt ; sa restitution au déposant s'effectue également pendant les heures d'ouverture du coffre. Le déposant garantit qu'il est le propriétaire légitime de la pièce, qu'elle est libre de tout gage et qu'elle n'est pas issue d'un vol ; il fournit à cette fin une pièce d'identité et, lorsqu'ils existent, les documents d'origine. Le règlement intervient par virement dans les 7 jours suivant l'encaissement du prix par Horlo-Gerie.</p>
          </article>

          <article className="art" id="art-11">
            <h2><span className="no">11</span>Limitation de responsabilité</h2>
            <p>La responsabilité d'Horlo-Gerie au titre d'une vente est limitée au prix payé pour la montre concernée. Elle ne saurait être engagée au titre de dommages indirects, ni d'un écart de rendu entre les photographies et l'objet réel tenant à l'affichage de l'écran de l'acheteur, les photographies étant produites avec le plus grand soin mais sans retouche du cadran ni du boîtier.</p>
          </article>

          <article className="art" id="art-12">
            <h2><span className="no">12</span>Données personnelles</h2>
            <p>Les données collectées — identité, adresse, courriel, historique de commande — sont utilisées pour traiter les commandes, tenir la comptabilité et, avec le consentement de la personne, envoyer la lettre des nouvelles pièces. Elles ne sont ni vendues ni cédées. Les données de commande sont conservées le temps des obligations comptables et fiscales ; les adresses de la lettre d'information le sont jusqu'à désinscription, possible en un clic dans chaque message.</p>
            <p>Conformément au RGPD, chacun dispose d'un droit d'accès, de rectification, d'effacement, de limitation et de portabilité, en écrivant à contact@horlo-gerie.fr. Une réclamation peut être adressée à la CNIL.</p>
          </article>

          <article className="art" id="art-13">
            <h2><span className="no">13</span>Droit applicable et litiges</h2>
            <p>Le vendeur dispose de points d'accueil à Paris, Lille et Bruxelles ; un point d'accueil londonien est en cours d'ouverture. Les présentes conditions sont soumises au droit français, sans que cela puisse priver l'acheteur consommateur des dispositions impératives plus protectrices du pays de sa résidence habituelle — notamment le droit belge pour les acheteurs résidant en Belgique. <span className="fill">Clause à confirmer selon la structure juridique retenue pour l'activité belge.</span> En cas de difficulté, l'acheteur est invité à nous contacter en premier lieu. À défaut d'accord amiable, il peut recourir gratuitement au médiateur de la consommation <span className="fill">nom du médiateur adhéré</span>, ou déposer une réclamation sur la plateforme européenne de règlement en ligne des litiges. À défaut, le litige relève des juridictions françaises compétentes.</p>
          </article>

          <p style={{ marginTop: 36 }}><a className="btn ghost" href="/boutique/">Retour à la collection</a></p>
        </div>
      </div>
    </div>
  );
}
