const THEMES = [
  {
    titre: 'Achat & paiement',
    q: [
      ['Comment se passe le paiement ?',
       'Chaque pièce dispose de son propre lien de paiement sécurisé Shopify. Vous réglez par carte bancaire sur la page de paiement Shopify ; nous ne voyons jamais vos coordonnées bancaires. Le virement bancaire est possible pour les montants élevés, sur demande.'],
      ['Les prix affichés sont-ils TTC ?',
       'Oui. Les prix sont toutes taxes comprises et relèvent du régime de la TVA sur marge applicable aux biens d’occasion : la TVA n’apparaît donc pas séparément sur la facture et n’est pas récupérable.'],
      ['Puis-je négocier le prix ?',
       'Le prix est fixé avec le déposant avant la mise en ligne, il n’est donc pas librement négociable. Si une pièce reste longtemps en collection, le prix peut être révisé — écrivez-nous, nous vous dirons où en est la pièce qui vous intéresse.'],
      ['Puis-je réserver une montre ?',
       'Oui, par e-mail, le temps de finaliser votre décision. Une réservation est tenue quelques jours ; elle ne devient ferme qu’au paiement.'],
    ],
  },
  {
    titre: 'Livraison & retours',
    q: [
      ['Sous quel délai la montre part-elle ?',
       'Sous 48 heures ouvrées après encaissement, sous réserve des heures d’ouverture du coffre où les pièces sont conservées. Vous recevez le numéro de suivi dès l’expédition.'],
      ['L’envoi est-il assuré ?',
       'Oui, chaque envoi est assuré pour la valeur de la montre et remis contre signature. Nous expédions en France et en Europe.'],
      ['Puis-je récupérer la montre en main propre ?',
       'Oui, à Paris, Lille ou Bruxelles, sur rendez-vous. Un point d’accueil est en cours d’ouverture à Londres.'],
      ['Ai-je un droit de rétractation ?',
       'Oui. Pour un achat à distance par un consommateur, vous disposez de quatorze jours calendaires à compter de la réception pour vous rétracter, conformément aux articles L.221-18 et suivants du Code de la consommation. La montre doit être retournée dans l’état où elle a été livrée, avec ses accessoires. Les frais de retour sont à votre charge sauf mention contraire, et le remboursement intervient dans les quatorze jours suivant le retour.'],
    ],
  },
  {
    titre: 'Garanties & contrôle',
    q: [
      ['Que contient le contrôle dont vous parlez ?',
       'Trois étapes, dans cet ordre, pour chaque pièce : ouverture et authentification (boîte, fond, couronne, calibre, numéros de série comparés aux références de la manufacture) ; contrôle sur banc (marche, amplitude, réserve de marche, étanchéité) avec révision chez un horloger si les valeurs sortent des tolérances ; puis remise avec le rapport de contrôle et la liste exacte des accessoires.'],
      ['Quelle garantie ai-je après l’achat ?',
       'La garantie légale de conformité s’applique pendant deux ans, ainsi que la garantie légale des vices cachés. Vous disposez par ailleurs de sept jours à réception pour inspecter la montre en main et nous signaler tout écart avec la description.'],
      ['Les montres sont-elles authentifiées ?',
       'Systématiquement, et c’est la condition d’entrée : une pièce dont l’authenticité n’est pas établie n’entre pas en collection. Les numéros de série sont relevés et vérifiés, et les composants comparés aux références de la manufacture.'],
      ['Que veulent dire « full set », « papiers seuls » et « révisée » ?',
       '« Full set » signifie que la boîte, les papiers et les accessoires d’origine sont présents. « Papiers seuls » signifie que seuls les papiers accompagnent la montre. « Révisée » est suivi de la date de la révision effectuée. Nous employons ces termes au sens strict : ce qui n’est pas annoncé n’est pas fourni.'],
    ],
  },
  {
    titre: 'Dépôt-vente',
    q: [
      ['Comment déposer une montre ?',
       'Écrivez-nous avec la référence et quelques photos. Nous vous répondons sous 48 heures avec une estimation, puis nous fixons ensemble le prix de vente. La commission est annoncée par écrit avant la mise en ligne, jamais après.'],
      ['Reste-je propriétaire pendant le dépôt ?',
       'Oui, vous restez propriétaire de la montre jusqu’à sa vente. Elle est assurée et conservée en coffre pendant toute la durée du dépôt.'],
      ['Quand suis-je payé après la vente ?',
       'Le virement est effectué dans les sept jours suivant la vente, une fois le délai d’inspection de l’acheteur écoulé.'],
      ['Prenez-vous toutes les marques ?',
       'Non. Une montre entre en dépôt si elle se revend : maison qui tient dans le temps, pièces détachées encore disponibles, cote connue du marché. La liste des maisons suivies est sur la page des marques, et elle n’est pas fermée — nous regardons au cas par cas.'],
    ],
  },
];

export const metadata = {
  title: 'Questions fréquentes — Horlo-Gerie',
  description: 'Paiement, livraison, rétractation, garanties, contrôle et dépôt-vente : les réponses aux questions les plus fréquentes.',
};

export default function Faq() {
  return (
    <div className="wrap legal" style={{ paddingBlock: 'clamp(26px,3.2vw,48px) clamp(60px,7vw,100px)' }}>
      <div style={{ maxWidth: '52em' }}>
        <span className="eyebrow">Questions fréquentes</span>
        <h1 style={{ fontSize: 'clamp(32px,4.2vw,58px)', marginTop: 14 }}>Ce qu’on nous demande le plus</h1>
        <p className="intro" style={{ margin: '16px 0 0', fontSize: 15, color: 'var(--steel-text)' }}>
          Les réponses ci-dessous reprennent exactement les positions énoncées dans nos conditions générales
          de vente. En cas de doute, ce sont les conditions qui font foi.
        </p>
      </div>

      {THEMES.map(t => (
        <section key={t.titre} style={{ marginTop: 'clamp(32px,4vw,56px)' }}>
          <h2 className="brand-sec-title">{t.titre}</h2>
          <div className="art">
            {t.q.map(([q, r]) => (
              <details key={q} className="faq-item">
                <summary>{q}</summary>
                <p>{r}</p>
              </details>
            ))}
          </div>
        </section>
      ))}

      <div className="search-box" style={{ marginTop: 'clamp(32px,4vw,56px)' }}>
        <div>
          <span className="eyebrow">Poser votre question</span>
          <h3>Votre question n’est pas là ?</h3>
          <p>Écrivez-nous : nous répondons sous 48 h, et si la question revient souvent, elle finit sur cette page.</p>
        </div>
        <div className="side">
          <a className="btn" href="mailto:contact@horlo-gerie.fr?subject=Question">Nous écrire</a>
          <p className="fine">Vous pouvez aussi ouvrir la discussion depuis votre espace client.</p>
        </div>
      </div>
    </div>
  );
}
