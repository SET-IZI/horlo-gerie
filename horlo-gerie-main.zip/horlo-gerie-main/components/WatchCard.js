'use client';
import { eur, watchPhoto, accLabel } from '../lib/supabase';
import { ageShort } from '../lib/age';
import FavButton from './FavButton';

export default function WatchCard({ w }) {
  const badge = w.etat === 'État neuf'
    ? <span className="tag gold">État neuf</span>
    : (w.acc === 'full' ? <span className="tag">Full set</span> : null);

  const ligne2 = [w.calibre ? w.calibre.split(',')[0] : null, w.diam, ageShort(w)]
    .filter(x => x && x !== '—').join(' · ');

  return (
    <div className="card">
      <a className="card-link" href={`/produit/?id=${encodeURIComponent(w.slug)}`}
         aria-label={`Voir la fiche : ${w.marque} ${w.modele}`} />
      <div className="ph">
        {badge}
        <FavButton watchId={w.id} />
        <img src={watchPhoto(w)} alt={`${w.marque} ${w.modele}`} loading="lazy" />
      </div>
      <div className="txt">
        <div className="brandline">
          <span className="b">{w.marque}</span>
          <span className="y">{w.annee}</span>
        </div>
        <h3>{w.modele}</h3>
        <div className="meta">
          {[w.etat, accLabel(w.acc)].filter(Boolean).join(' · ')}
          {ligne2 && <><br />{ligne2}</>}
        </div>
        <div className="foot">
          <span className="price">{eur(w.prix)}</span>
          <span className="see">Voir</span>
        </div>
      </div>
    </div>
  );
}
