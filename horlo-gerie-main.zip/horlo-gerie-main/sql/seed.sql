-- Seed : les pièces du prototype, à titre d'exemple. Remplace par ton vrai stock,
-- ou garde-les le temps de brancher l'admin (photos hébergées sur Supabase Storage,
-- ici on met un tableau vide en attendant l'upload des vraies photos).

insert into watches (slug, marque, modele, ref, annee, prix, etat, acc, calibre, diam, revision, description, status)
values
  ('speedmaster-3570', 'Omega', 'Speedmaster Professional', '3570.50.00', 2004, 4900, 'Très bon', 'full', '1861, remontage manuel', '42 mm', 'Révisée 03/2026', 'Hésalite et fond plein, comme la Moonwatch d’origine. Boîte et papiers d’époque, bracelet 1998/849 complet. Amplitude 275° cadran en haut, marche +3 s/j après révision.', 'publie'),
  ('sub-16610', 'Rolex', 'Submariner Date', '16610', 1998, 9800, 'Très bon', 'papiers', '3135, automatique', '40 mm', 'Révisée 11/2025', 'Lunette aluminium d’origine, légèrement passée. Verre saphir sans rayure, bracelet Oyster 93150 avec jeu réduit. Papiers d’origine, boîte non fournie.', 'publie'),
  ('santos-moyen', 'Cartier', 'Santos de Cartier, moyen modèle', 'WSSA0029', 2021, 5900, 'Excellent', 'full', '1847 MC, automatique', '35,1 mm', 'Contrôlée 08/2026', 'Système QuickSwitch, second bracelet cuir noir fourni. Full set, facture d’achat en boutique.', 'publie'),
  ('bb58', 'Tudor', 'Black Bay Fifty-Eight', '79030N', 2020, 3100, 'Très bon', 'full', 'MT5402, automatique', '39 mm', 'Contrôlée 05/2026', 'Bracelet rivets acier, fermoir sans micro-rayure notable. Carte de garantie datée 2020, boîte et papiers.', 'publie'),
  ('sub-16613', 'Rolex', 'Submariner Date acier &amp; or', '16613', 1995, 10900, 'Bon', 'full', '3135, automatique', '40 mm', 'Révisée 06/2025', 'Cadran noir, index or. Traces d’usage cohérentes avec l’âge, boîtier jamais repoli. Full set : boîte, papiers, maillons, étiquettes.', 'publie'),
  ('datejust-choco', 'Rolex', 'Datejust 31 cadran chocolat', '178271', 2016, 8400, 'Excellent', 'full', '2235, automatique', '31 mm', 'Contrôlée 08/2026', 'Everose et acier, cadran chocolat index diamants. Portée quelques mois seulement, protections d’origine sur le fermoir.', 'publie'),
  ('speedy-racing', 'Omega', 'Speedmaster Racing Co-Axial', '329.30.44.51.01.002', 2019, 5400, 'État neuf', 'full', '9900, automatique', '44,25 mm', 'Contrôlée 07/2026', 'Chronographe Master Chronometer certifié METAS. Aucune marque d’usage, garantie internationale encore en cours.', 'publie'),
  ('navitimer-b01', 'Breitling', 'Navitimer B01 Chronograph 43', 'AB0121211G1P1', 2019, 6300, 'Excellent', 'full', 'B01, automatique', '43 mm', 'Contrôlée 06/2026', 'Cadran argenté, règle à calcul circulaire intacte. Bracelet cuir noir d’origine, boucle déployante.', 'publie'),
  ('tank-louis', 'Cartier', 'Tank Louis Cartier, or jaune', 'W1529856', 2012, 7800, 'Excellent', 'full', '430 MC, remontage manuel', '33,7 × 25,5 mm', 'Contrôlée 07/2026', 'Or jaune 18 ct, cadran argenté guilloché, chiffres romains. Écrin rouge et papiers d’origine.', 'publie'),
  ('datejust-16234', 'Rolex', 'Datejust 36', '16234', 2001, 6900, 'Très bon', 'papiers', '3135, automatique', '36 mm', 'Révisée 09/2025', 'Lunette cannelée or gris, cadran argent index bâtons. Bracelet Jubilé acier, jeu léger. Papiers d’origine.', 'publie'),
  ('speedmaster-1971', 'Omega', 'Speedmaster « pre-moon » tardive', '145.022-71', 1971, 6200, 'Bon', 'aucun', '861, remontage manuel', '42 mm', 'Révisée 12/2025', 'Cadran step, lunette DON remplacée en service. Extrait d’archives Omega fourni. Pièce vendue sans boîte.', 'publie'),
  ('longines-conquest', 'Longines', 'Conquest calendrier', '9025', 1962, 1450, 'Bon', 'aucun', '19AS, automatique', '35 mm', 'Révisée 01/2026', 'Boîtier acier, fond vissé avec médaillon émaillé. Cadran d’origine non restauré, quelques taches de patine honnêtes.', 'publie'),
  ('tissot-seastar', 'Tissot', 'Seastar automatique', '44571-1X', 1968, 690, 'Bon', 'aucun', '784-2, automatique', '34 mm', 'Révisée 02/2026', 'Cadran argenté légèrement patiné, aiguilles d’origine. Bracelet cuir neuf. Vendue sans boîte ni papiers, comme la plupart des pièces de cette époque.', 'publie'),
  ('seiko-lord-matic', 'Seiko', 'Lord Matic', '5606-7000', 1974, 420, 'Bon', 'aucun', '5606, automatique', '36 mm', 'Révisée 04/2026', 'Cadran noir, jour-date bilingue. Révisée et étanchéité contrôlée. Une entrée en horlogerie mécanique qui ne triche pas.', 'publie');

-- Ventes réalisées (archive), avec date + prix de vente réels
insert into watches (slug, marque, modele, ref, annee, prix, status, vendu_prix, vendu_le)
values
  ('rolex-gmt-master-ii-batman-vendu', 'Rolex', 'GMT-Master II « Batman »', '116710BLNR', 2015, 14200, 'vendu', 14200, '2026-08-01'),
  ('omega-speedmaster-professional-vendu', 'Omega', 'Speedmaster Professional', '145.022', 1978, 7400, 'vendu', 7400, '2026-08-01'),
  ('cartier-santos-dumont-or-rose-vendu', 'Cartier', 'Santos Dumont, or rose', 'W2SA0011', 2020, 9600, 'vendu', 9600, '2026-07-01'),
  ('tudor-black-bay-chrono-vendu', 'Tudor', 'Black Bay Chrono', '79350', 2021, 4300, 'vendu', 4300, '2026-07-01'),
  ('rolex-datejust-41-cadran-ardoise-vendu', 'Rolex', 'Datejust 41 cadran ardoise', '126300', 2019, 9100, 'vendu', 9100, '2026-06-01'),
  ('breitling-navitimer-806-reedition-1959-vendu', 'Breitling', 'Navitimer 806 réédition 1959', 'AB0910', 2019, 5800, 'vendu', 5800, '2026-05-01'),
  ('omega-seamaster-300-master-co-axial-vendu', 'Omega', 'Seamaster 300 Master Co-Axial', '233.30.41', 2017, 4100, 'vendu', 4100, '2026-04-01'),
  ('longines-flagship-automatique-or-18-ct-vendu', 'Longines', 'Flagship automatique, or 18 ct', '3406', 1959, 2350, 'vendu', 2350, '2026-03-01'),
  ('rolex-oyster-perpetual-36-vendu', 'Rolex', 'Oyster Perpetual 36', '126000', 2022, 6700, 'vendu', 6700, '2026-02-01'),
  ('cartier-tank-must-grand-modele-vendu', 'Cartier', 'Tank Must, grand modèle', 'WSTA0053', 2021, 2900, 'vendu', 2900, '2026-02-01'),
  ('zenith-el-primero-chronomaster-vendu', 'Zenith', 'El Primero Chronomaster', '03.2040', 2014, 4600, 'vendu', 4600, '2026-01-01'),
  ('seiko-grand-seiko-snowflake-vendu', 'Seiko', 'Grand Seiko Snowflake', 'SBGA211', 2018, 3800, 'vendu', 3800, '2026-01-01');