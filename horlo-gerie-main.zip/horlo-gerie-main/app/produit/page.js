'use client';
import { useEffect, useState } from 'react';
import { getWatch, eur, accLabel, watchPhoto } from '../../lib/supabase';
import { ageLong, ageShort, prodOf, dateFr } from '../../lib/age';
import { C24_URL } from '../../lib/site-data';
import FavButton from '../../components/FavButton';

function AgeBox({ w }) {
  const p = prodOf(w);
  if (!p) {
    if (!w.annee) return null;
    return (
      <div className="agebox">
        <p>Cette <b>{w.marque} {w.modele}</b> a aujourd’hui <b>environ {new Date().getFullYear() - w.annee} ans</b>.</p>
        <span className="src">Seule l’année de production est connue pour cette référence : nous n’affichons pas de date au jour près que nous ne pourrions pas prouver.</span>
      </div>
    );
  }
  return (
    <div className="agebox">
      <p>Cette <b>{w.marque} {w.modele}</b> a aujourd’hui <b>{ageLong(w)}</b>.</p>
      <span className="src">Calculé depuis le {dateFr(p[0])}, date portée sur {p[1]}.</span>
    </div>
  );
}

export default function Produit() {
  const [w, setW] = useState(undefined);
  const [shot, setShot] = useState(0);

  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get('id');
    if (!id) { setW(null); return; }
    getWatch(id).then(setW);
  }, []);

  if (w === undefined) return <div className="wrap"><p className="empty">Chargement…</p></div>;
  if (w === null) {
    return (
      <div className="wrap" style={{ paddingBlock: 60 }}>
        <div className="empty-state">
          <p>Cette pièce n’est plus disponible, ou le lien est incomplet.</p>
          <a className="btn ghost" href="/boutique/">Voir la collection</a>
        </div>
      </div>
    );
  }

  const photos = (w.photos && w.photos.length) ? w.photos : [watchPhoto(w)];
  const vendue = w.status === 'vendu';
  const specs = [
    ['Année', w.annee],
    ['Âge', ageShort(w)],
    ['Calibre', w.calibre],
    ['Diamètre', w.diam],
    ['État', w.etat],
    ['Accessoires', accLabel(w.acc)],
    ['Contrôle', w.revision],
  ].filter(([, v]) => v);

  return (
    <article className="panel fiche-page">
      <div className="top">
        <span className="smallcaps">{w.marque} · Réf. {w.ref || '—'}</span>
        <a className="linkbtn" href="/boutique/">Retour à la collection</a>
      </div>

      <div className="ph">
        <FavButton watchId={w.id} />
        <img src={photos[shot]} alt={`${w.marque} ${w.modele}`} />
      </div>

      {photos.length > 1 && (
        <div className="gal">
          {photos.map((p, i) => (
            <button key={p + i} type="button" aria-current={i === shot} aria-label={`Photo ${i + 1}`} onClick={() => setShot(i)}>
              <img src={p} alt="" />
            </button>
          ))}
        </div>
      )}

      <div className="body">
        <div>
          <span className="smallcaps">{w.marque}{w.annee ? ` · ${w.annee}` : ''}</span>
          <h2>{w.modele}</h2>
          {w.ref && <div className="ref">Référence {w.ref}</div>}
        </div>

        <div className="pricebar">
          <div className="p">
            {eur(vendue && w.vendu_prix != null ? w.vendu_prix : w.prix)}
            <small>TTC · TVA sur marge</small>
          </div>
          <div className="av">{vendue ? 'Vendue' : 'Disponible'}</div>
        </div>

        <AgeBox w={w} />

        <dl className="specs">
          {specs.map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}
        </dl>

        {w.description && <p className="desc">{w.description}</p>}

        <div className="warr">
          <div><b>7 jours</b>pour inspecter la montre à réception</div>
          <div><b>2 ans</b>de garantie légale de conformité</div>
          <div><b>Rapport</b>de contrôle fourni avec la pièce</div>
        </div>

        <div className="acts">
          {vendue ? (
            <a className="btn ghost" href="/boutique/">Voir les pièces disponibles</a>
          ) : w.checkout_url ? (
            <a className="btn gold" href={w.checkout_url} target="_blank" rel="noopener noreferrer">
              Acheter — paiement sécurisé
            </a>
          ) : (
            <span className="btn gold" aria-disabled="true" style={{ opacity: .5, cursor: 'not-allowed' }}
                  title="Lien de paiement Shopify à renseigner dans l’administration">
              Acheter — paiement sécurisé
            </span>
          )}
          <a className="btn ghost"
             href={`mailto:contact@horlo-gerie.fr?subject=${encodeURIComponent(`Question — ${w.marque} ${w.modele}${w.ref ? ` (réf. ${w.ref})` : ''}`)}`}>
            Poser une question
          </a>
          {C24_URL.trim() && (
            <a className="btn ghost" href={C24_URL} target="_blank" rel="noopener noreferrer">
              Voir sur Chrono24
            </a>
          )}
        </div>

        <p className="note">
          Paiement par lien Shopify sécurisé. Montre conservée en coffre, expédiée en envoi assuré sous 48 h
          ouvrées après encaissement, sous réserve des heures d’ouverture du coffre. Remise en main propre
          possible à Paris, Lille ou Bruxelles. Inspection de 7 jours à réception — voir les{' '}
          <a href="/conditions/" style={{ textDecoration: 'underline', textUnderlineOffset: 3 }}>conditions de vente</a>.
        </p>
      </div>
    </article>
  );
}
