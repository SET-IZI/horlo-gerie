'use client';
import { useEffect, useState } from 'react';
import { getSoldWatches } from '../../lib/supabase';
import SoldCard, { moisDeVente } from '../../components/SoldCard';

export default function Vendues() {
  const [sold, setSold] = useState(null);
  useEffect(() => { getSoldWatches().then(setSold); }, []);

  const liste = sold || [];
  const maisons = new Set(liste.map(w => w.marque)).size;
  const premiere = liste.length ? moisDeVente(liste[liste.length - 1].vendu_le) : '—';

  return (
    <>
      <div className="wrap sold-head">
        <div className="row">
          <div><span className="eyebrow">Archive</span><h1>Ventes réalisées</h1></div>
        </div>
        <p className="intro">
          Les pièces déjà parties. Elles ne sont plus disponibles : cette page existe pour montrer ce qui
          passe entre nos mains, et à quel prix. Les montants affichés sont les prix de vente réels,
          commission comprise.
        </p>
        <div className="sold-stats">
          <div><b>{liste.length}</b><span>pièce{liste.length > 1 ? 's' : ''} vendue{liste.length > 1 ? 's' : ''}</span></div>
          <div><b>{premiere}</b><span>première vente enregistrée</span></div>
          <div><b>{maisons}</b><span>maison{maisons > 1 ? 's' : ''} représentée{maisons > 1 ? 's' : ''}</span></div>
        </div>
      </div>

      <div className="wrap" style={{ paddingBottom: 'clamp(60px,7vw,104px)' }}>
        {sold === null ? (
          <p className="empty">Chargement…</p>
        ) : liste.length ? (
          <div className="grid-4" style={{ marginTop: 'clamp(24px,3vw,40px)' }}>
            {liste.map(w => <SoldCard key={w.id} w={w} />)}
          </div>
        ) : (
          <div className="empty-state"><p>Aucune vente enregistrée pour l’instant.</p></div>
        )}
        <div className="sold-note" style={{ marginTop: 'var(--gap)' }}>
          Une pièce de cette archive vous intéresse ? Nous en retrouvons régulièrement d’équivalentes —
          décrivez-nous ce que vous cherchez et nous vous écrivons dès qu’une montre correspond.{' '}
          <a href="mailto:contact@horlo-gerie.fr?subject=Recherche%20personnalis%C3%A9e"
             style={{ color: 'var(--ink)', textDecoration: 'underline', textUnderlineOffset: 3 }}>
            Décrire ma recherche
          </a>.
        </div>
      </div>
    </>
  );
}
