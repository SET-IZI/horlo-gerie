'use client';
import { useState, useRef } from 'react';
import { shrinkImage, uploadWatchPhoto } from '../lib/supabase';

// photos: array of URLs (déjà en ligne). onChange(newArray) à chaque changement.
export default function PhotoUploader({ photos, onChange, watchSlug }) {
  const [busy, setBusy] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [dragIndex, setDragIndex] = useState(null);
  const inputRef = useRef(null);

  async function addFiles(fileList) {
    const files = Array.from(fileList).filter(f => f.type.startsWith('image/'));
    if (!files.length) return;
    setBusy(true);
    const newUrls = [];
    for (const file of files) {
      try {
        const blob = await shrinkImage(file);
        const { url, error } = await uploadWatchPhoto(blob, watchSlug);
        if (url) newUrls.push(url);
        if (error) console.error(error);
      } catch (e) { console.error(e); }
    }
    onChange([...(photos || []), ...newUrls]);
    setBusy(false);
  }

  function removeAt(i) {
    const next = [...photos];
    next.splice(i, 1);
    onChange(next);
  }

  function reorder(from, to) {
    if (from === to) return;
    const next = [...photos];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    onChange(next);
  }

  return (
    <div>
      <div
        className={`dropzone${dragOver ? ' over' : ''}`}
        onClick={() => inputRef.current?.click()}
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={e => {
          e.preventDefault(); setDragOver(false);
          if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files);
        }}
      >
        <input
          ref={inputRef} type="file" accept="image/*" multiple hidden
          onChange={e => { if (e.target.files?.length) addFiles(e.target.files); e.target.value = ''; }}
        />
        {busy ? 'Envoi en cours…' : 'Glisse des photos ici, ou clique pour en choisir'}
      </div>

      {photos && photos.length > 0 && (
        <div className="thumbs">
          {photos.map((url, i) => (
            <div
              key={url + i}
              className={`thumb${i === 0 ? ' main' : ''}`}
              draggable
              onDragStart={() => setDragIndex(i)}
              onDragOver={e => e.preventDefault()}
              onDrop={() => { if (dragIndex !== null) reorder(dragIndex, i); setDragIndex(null); }}
            >
              <img src={url} alt="" />
              {i === 0 && <span className="tag">Principale</span>}
              <button type="button" className="rm" onClick={() => removeAt(i)} aria-label="Retirer">×</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
