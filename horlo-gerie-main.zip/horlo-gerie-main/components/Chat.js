'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  supabase, getMyMessages, sendMyMessage, markAdminMessagesRead, countMyUnread, heureFr,
} from '../lib/supabase';

// Tchat visiteur. La conversation est stockée dans Supabase (table messages),
// donc elle survit à la fermeture du navigateur et l'admin peut répondre plus tard.
export default function Chat() {
  const [ouvert, setOuvert] = useState(false);
  const [connecte, setConnecte] = useState(null);
  const [messages, setMessages] = useState([]);
  const [texte, setTexte] = useState('');
  const [nonLus, setNonLus] = useState(0);
  const logRef = useRef(null);

  const charger = useCallback(async () => {
    const { messages: m, connecte: c } = await getMyMessages();
    setConnecte(c);
    setMessages(m);
  }, []);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setConnecte(!!user);
      if (user) countMyUnread().then(setNonLus);
    });
  }, []);

  // Suivi en direct des réponses de l'admin
  useEffect(() => {
    if (!connecte) return;
    const canal = supabase
      .channel('messages-client')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => {
        if (ouvert) charger(); else countMyUnread().then(setNonLus);
      })
      .subscribe();
    return () => { supabase.removeChannel(canal); };
  }, [connecte, ouvert, charger]);

  useEffect(() => {
    if (!ouvert) return;
    charger().then(() => { markAdminMessagesRead(); setNonLus(0); });
  }, [ouvert, charger]);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [messages, ouvert]);

  async function envoyer(e) {
    e.preventDefault();
    const v = texte.trim();
    if (!v) return;
    setTexte('');
    setMessages(m => [...m, { id: 'tmp' + Date.now(), auteur: 'client', texte: v, created_at: new Date().toISOString() }]);
    await sendMyMessage(v);
    charger();
  }

  if (!ouvert) {
    return (
      <button className="chat-launch" onClick={() => setOuvert(true)}>
        <span className="dot" />Discuter avec nous
        {nonLus > 0 && <span className="n">{nonLus}</span>}
      </button>
    );
  }

  return (
    <aside className="chatbox" aria-label="Discussion avec Horlo-Gerie">
      <div className="chat-head">
        <div>
          <b>Horlo-Gerie</b>
          <span>Nous répondons en général sous 10 minutes</span>
        </div>
        <button className="iconbtn" onClick={() => setOuvert(false)} aria-label="Fermer la discussion">✕</button>
      </div>

      {connecte === false ? (
        <div className="chat-gate">
          <p>Connectez-vous pour discuter avec nous : vous retrouverez la conversation, et nous pourrons vous répondre même après votre départ du site.</p>
          <a className="btn" href="/compte/">Se connecter</a>
        </div>
      ) : (
        <>
          <div className="chat-log" ref={logRef}>
            {messages.length === 0 && (
              <div className="msg them">
                Bonjour, comment pouvons-nous vous aider ? Une pièce en particulier, une estimation, un dépôt ?
                <span className="t">À l’instant</span>
              </div>
            )}
            {messages.map(m => (
              <div key={m.id} className={`msg ${m.auteur === 'admin' ? 'them' : 'me'}`}>
                {m.texte}
                <span className="t">{heureFr(m.created_at)}</span>
              </div>
            ))}
          </div>
          <form className="chat-form" onSubmit={envoyer}>
            <input
              value={texte} onChange={e => setTexte(e.target.value)}
              placeholder="Votre message…" aria-label="Votre message" autoComplete="off"
            />
            <button type="submit">Envoyer</button>
          </form>
        </>
      )}
    </aside>
  );
}
