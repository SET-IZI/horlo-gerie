'use client';
import { useState } from 'react';
import { subscribeNewsletter } from '../lib/supabase';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!/.+@.+\..+/.test(email)) { setMsg({ ok: false, t: 'Cette adresse ne semble pas valide.' }); return; }
    setBusy(true);
    const { error } = await subscribeNewsletter(email);
    setBusy(false);
    if (error && error.code !== '23505') { setMsg({ ok: false, t: 'Enregistrement impossible pour le moment.' }); return; }
    setMsg({ ok: true, t: 'C’est noté — vous recevrez les prochaines entrées en collection.' });
    setEmail('');
  }

  return (
    <div className="news">
      <h4>Lettre des nouvelles pièces</h4>
      <p className="sub">Un message quand des montres entrent en collection — deux à trois par mois, jamais plus.</p>
      <form onSubmit={handleSubmit} noValidate>
        <input
          type="email" name="email" placeholder="votre@email.fr" autoComplete="email"
          aria-label="Votre adresse e-mail" value={email} onChange={e => setEmail(e.target.value)} required
        />
        <button type="submit" className="btn" disabled={busy}>{busy ? '…' : 'S’inscrire'}</button>
        {msg && <div className={`msg${msg.ok ? ' ok' : ' ko'}`} role="alert">{msg.t}</div>}
        <p className="consent">Vos coordonnées servent uniquement à l’envoi de cette lettre. Désinscription en un clic dans chaque message.</p>
      </form>
    </div>
  );
}
