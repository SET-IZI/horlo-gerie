import { eur, watchPhoto } from '../lib/supabase';

const MOIS = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];

export function moisDeVente(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return `${MOIS[d.getMonth()]} ${d.getFullYear()}`;
}

export default function SoldCard({ w }) {
  return (
    <div className="card sold">
      <div className="ph">
        <span className="tag vendue">Vendue</span>
        <img src={watchPhoto(w)} alt={`${w.marque} ${w.modele}`} loading="lazy" />
      </div>
      <div className="txt">
        <div className="brandline">
          <span className="b">{w.marque}</span>
          <span className="y">{w.annee}</span>
        </div>
        <h3>{w.modele}</h3>
        <div className="meta">{w.ref ? `Réf. ${w.ref}` : ' '}</div>
        <div className="foot">
          <span className="price">{eur(w.vendu_prix != null ? w.vendu_prix : w.prix)}</span>
          <span className="when">{moisDeVente(w.vendu_le)}</span>
        </div>
      </div>
    </div>
  );
}
