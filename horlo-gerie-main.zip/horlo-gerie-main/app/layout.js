import '../styles/globals.css';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import VisitLogger from '../components/VisitLogger';
import Chat from '../components/Chat';

export const metadata = {
  title: 'Horlo-Gerie — Dépôt-vente de montres',
  description: "Horlo-Gerie, dépôt-vente de montres d'occasion et en état neuf, contrôlées une à une. Paris, Lille, Bruxelles.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Jost:wght@200;300;400;500&family=Manrope:wght@400;500;600;700;800&display=swap" />
      </head>
      <body>
        <VisitLogger />
        <Navbar />
        <main>{children}</main>
        <Footer />
        <Chat />
      </body>
    </html>
  );
}
