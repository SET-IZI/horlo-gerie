'use client';
import { useState } from 'react';
import { saveWatch, slugify, searchClients, saveCommande, checkWatch, listeFr } from '../lib/supabase';
import PhotoUploader from './PhotoUploader';

const EMPTY = {
  marque: '', modele: '', ref: '', annee: '', prix: '', etat: 'Très bon', acc: 'full',
  calibre: '', diam: '', revision: '', description: '', photos: [], checkout_url: '',
  status: 'brouillon',
};

export default function WatchForm({ watch, onSaved, onCancel }) {
  const [w, setW] = useState(watch ? { ...watch } : { ...EMPTY });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [clientQuery, setClientQuery] = useState('');
  const [clientResults, setClientResults] = useState([]);
  const [client, setClient] = useState(null);

  function set(field, value) { setW(prev => ({ ...prev, [field]: value })); }

  const controle = checkWatch(w);

  async function handleClientQuery(v) {
    setClientQuery(v); setClient(null);
    setClientResults(v.trim().length >= 2 ? await searchClients(v) : []);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (w.status === 'publie' && !controle.publiable) {
      setErr(`Pour publier cette pièce, il manque ${listeFr(controle.manquants)}. Tu peux l'enregistrer en brouillon en attendant.`);
      return;
    }
    setSaving(true); setErr('');
    const payload = {
      ...w,
      slug: w.slug || slugify(`${w.marque}-${w.modele}-${Date.now().toString(36)}`),
      annee: w.annee ? parseInt(w.annee, 10) : null,
      prix: w.prix ? parseFloat(w.prix) : null,
      vendu_prix: w.vendu_prix ? parseFloat(w.vendu_prix) : null,
    };
    const { data, error } = await saveWatch(payload);
    if (!error && data.status === 'vendu' && client) {
      await saveCommande({ client_id: client.id, watch_id: data.id, prix: data.vendu_prix || data.prix, date: data.vendu_le || null });
    }
    setSaving(false);
    if (error) { setErr(error.message); return; }
    onSaved(data);
  }

  return (
    <form className="watch-form" onSubmit={handleSubmit}>
      <h2>{watch ? 'Modifier la pièce' : 'Ajouter une pièce'}</h2>
      {err && <p className="err">{err}</p>}

      {(controle.manquants.length > 0 || controle.aCompleter.length > 0) && (
        <div className="form-check">
          {controle.manquants.length > 0 && (
            <p className="miss">Nécessaire pour publier : {listeFr(controle.manquants)}.</p>
          )}
          {controle.aCompleter.length > 0 && (
            <p>À compléter : {listeFr(controle.aCompleter)}.</p>
          )}
        </div>
      )}

      <div className="fgrid">
        <label>Marque<input required value={w.marque} onChange={e => set('marque', e.target.value)} /></label>
        <label>Modèle<input required value={w.modele} onChange={e => set('modele', e.target.value)} /></label>
        <label>Référence<input value={w.ref || ''} onChange={e => set('ref', e.target.value)} /></label>
        <label>Année<input type="number" value={w.annee || ''} onChange={e => set('annee', e.target.value)} /></label>
        <label>Prix (€)<input required type="number" step="1" value={w.prix || ''} onChange={e => set('prix', e.target.value)} /></label>
        <label>État
          <select value={w.etat || ''} onChange={e => set('etat', e.target.value)}>
            {['Bon', 'Très bon', 'Excellent', 'État neuf'].map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        </label>
        <label>Accessoires
          <select value={w.acc || 'aucun'} onChange={e => set('acc', e.target.value)}>
            <option value="full">Full set</option>
            <option value="papiers">Papiers seuls</option>
            <option value="aucun">Sans boîte ni papiers</option>
          </select>
        </label>
        <label>Calibre<input value={w.calibre || ''} onChange={e => set('calibre', e.target.value)} /></label>
        <label>Diamètre<input value={w.diam || ''} onChange={e => set('diam', e.target.value)} /></label>
        <label>Dernier contrôle<input value={w.revision || ''} onChange={e => set('revision', e.target.value)} placeholder="Révisée 03/2026" /></label>
        <label>Lien de paiement Shopify<input value={w.checkout_url || ''} onChange={e => set('checkout_url', e.target.value)} placeholder="https://..." /></label>
        <label>Statut
          <select value={w.status} onChange={e => set('status', e.target.value)}>
            <option value="brouillon">Brouillon (invisible du public)</option>
            <option value="publie">Publiée</option>
            <option value="vendu">Vendue</option>
          </select>
        </label>
      </div>

      {w.status === 'vendu' && (
        <>
          <div className="fgrid">
            <label>Prix de vente réel<input type="number" value={w.vendu_prix || ''} onChange={e => set('vendu_prix', e.target.value)} /></label>
            <label>Date de vente<input type="date" value={w.vendu_le || ''} onChange={e => set('vendu_le', e.target.value)} /></label>
          </div>
          <label className="block">Rattacher au client acheteur <span style={{ fontWeight: 400 }}>(facultatif — uniquement s'il a un compte sur le site)</span>
            <input
              placeholder="Nom ou e-mail du client…"
              value={client ? `${client.nom || client.email}` : clientQuery}
              onChange={e => handleClientQuery(e.target.value)}
            />
          </label>
          {clientResults.length > 0 && !client && (
            <div className="client-picker">
              {clientResults.map(c => (
                <button type="button" key={c.id} onClick={() => { setClient(c); setClientResults([]); }}>
                  {c.nom || '(sans nom)'} — {c.email}
                </button>
              ))}
            </div>
          )}
        </>
      )}

      <label className="block">Description
        <textarea rows={4} value={w.description || ''} onChange={e => set('description', e.target.value)} />
      </label>

      <label className="block">Photos</label>
      <PhotoUploader photos={w.photos || []} onChange={p => set('photos', p)} watchSlug={w.slug || slugify(w.marque + '-' + w.modele)} />

      <div className="fbar">
        <button type="button" className="btn ghost" onClick={onCancel}>Annuler</button>
        <button type="submit" className="btn solid" disabled={saving}>{saving ? 'Enregistrement…' : 'Enregistrer'}</button>
      </div>
    </form>
  );
}
