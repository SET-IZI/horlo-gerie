-- ═══════════════════════════════════════════════════════════════
--  HORLO-GERIE — installation complète de la base
--  À coller dans Supabase → SQL Editor → Run. Rejouable sans risque.
-- ═══════════════════════════════════════════════════════════════

create extension if not exists pgcrypto;

-- ─────────────── MONTRES ───────────────
create table if not exists watches (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  marque text not null,
  modele text not null,
  ref text,
  annee int,
  date_prod date,
  date_source text,
  prix numeric not null,
  etat text,
  acc text,
  calibre text,
  diam text,
  revision text,
  description text,
  photos text[] default '{}',
  checkout_url text,
  status text not null default 'brouillon' check (status in ('brouillon','publie','vendu')),
  vendu_prix numeric,
  vendu_le date,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists watches_status_idx on watches(status);
create index if not exists watches_marque_idx on watches(marque);
alter table watches enable row level security;

-- ─────────────── ADMINS ───────────────
create table if not exists admins (email text primary key);
alter table admins enable row level security;

-- ─────────────── CLIENTS ───────────────
create table if not exists clients (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  nom text,
  telephone text,
  created_at timestamptz default now()
);
alter table clients enable row level security;

create or replace function public.handle_new_client()
returns trigger as $$
begin
  insert into public.clients (id, email) values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer set search_path = public;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_client();

-- ─────────────── FAVORIS ───────────────
create table if not exists favoris (
  client_id uuid references clients(id) on delete cascade,
  watch_id uuid references watches(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (client_id, watch_id)
);
alter table favoris enable row level security;

-- ─────────────── COMMANDES ───────────────
create table if not exists commandes (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references clients(id) on delete set null,
  watch_id uuid references watches(id) on delete set null,
  prix numeric,
  date date default current_date,
  created_at timestamptz default now()
);
alter table commandes enable row level security;

-- ─────────────── VISITES ───────────────
-- client_id peut être nul : on journalise aussi les visiteurs non connectés.
create table if not exists visites (
  id bigint generated always as identity primary key,
  client_id uuid references clients(id) on delete cascade,
  chemin text,
  ip text,
  user_agent text,
  created_at timestamptz default now()
);
alter table visites alter column client_id drop not null;
alter table visites add column if not exists ip text;
alter table visites add column if not exists user_agent text;
create index if not exists visites_client_idx on visites(client_id, created_at desc);
create index if not exists visites_ip_idx on visites(ip, created_at desc);
alter table visites enable row level security;

-- ─────────────── MESSAGES (tchat) ───────────────
create table if not exists messages (
  id bigint generated always as identity primary key,
  client_id uuid not null references clients(id) on delete cascade,
  auteur text not null check (auteur in ('client','admin')),
  texte text not null,
  lu boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists messages_client_idx on messages(client_id, created_at);
alter table messages enable row level security;

-- ─────────────── NEWSLETTER ───────────────
create table if not exists newsletter (
  email text primary key,
  created_at timestamptz not null default now(),
  source text default 'site'
);
alter table newsletter enable row level security;

-- ═══════════════ RÈGLES D'ACCÈS ═══════════════
drop policy if exists "watches_public_read" on watches;
create policy "watches_public_read" on watches for select
  using (status in ('publie','vendu'));

drop policy if exists "watches_admin_all" on watches;
create policy "watches_admin_all" on watches for all
  using ((auth.jwt() ->> 'email') in (select email from admins))
  with check ((auth.jwt() ->> 'email') in (select email from admins));

drop policy if exists "admins_self_read" on admins;
create policy "admins_self_read" on admins for select
  using (auth.jwt() ->> 'email' = email);

drop policy if exists "clients_self_all" on clients;
create policy "clients_self_all" on clients for all
  using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "clients_admin_read" on clients;
create policy "clients_admin_read" on clients for select
  using ((auth.jwt() ->> 'email') in (select email from admins));

drop policy if exists "favoris_self_all" on favoris;
create policy "favoris_self_all" on favoris for all
  using (auth.uid() = client_id) with check (auth.uid() = client_id);

drop policy if exists "favoris_admin_read" on favoris;
create policy "favoris_admin_read" on favoris for select
  using ((auth.jwt() ->> 'email') in (select email from admins));

drop policy if exists "commandes_self_read" on commandes;
create policy "commandes_self_read" on commandes for select
  using (auth.uid() = client_id);

drop policy if exists "commandes_admin_all" on commandes;
create policy "commandes_admin_all" on commandes for all
  using ((auth.jwt() ->> 'email') in (select email from admins))
  with check ((auth.jwt() ->> 'email') in (select email from admins));

-- Journalisation ouverte (le visiteur non connecté doit pouvoir écrire sa ligne),
-- mais lecture réservée au client concerné et aux admins.
drop policy if exists "visites_insert_open" on visites;
create policy "visites_insert_open" on visites for insert with check (true);

drop policy if exists "visites_self_read" on visites;
create policy "visites_self_read" on visites for select
  using (auth.uid() = client_id);

drop policy if exists "visites_admin_read" on visites;
create policy "visites_admin_read" on visites for select
  using ((auth.jwt() ->> 'email') in (select email from admins));

drop policy if exists "messages_self_read" on messages;
create policy "messages_self_read" on messages for select
  using (auth.uid() = client_id);

drop policy if exists "messages_self_insert" on messages;
create policy "messages_self_insert" on messages for insert
  with check (auth.uid() = client_id and auteur = 'client');

drop policy if exists "messages_self_update" on messages;
create policy "messages_self_update" on messages for update
  using (auth.uid() = client_id) with check (auth.uid() = client_id);

drop policy if exists "messages_admin_all" on messages;
create policy "messages_admin_all" on messages for all
  using ((auth.jwt() ->> 'email') in (select email from admins))
  with check ((auth.jwt() ->> 'email') in (select email from admins));

drop policy if exists "newsletter_insert_open" on newsletter;
create policy "newsletter_insert_open" on newsletter for insert with check (true);

drop policy if exists "newsletter_admin_read" on newsletter;
create policy "newsletter_admin_read" on newsletter for select
  using ((auth.jwt() ->> 'email') in (select email from admins));

-- ═══════════════ STOCKAGE DES PHOTOS ═══════════════
insert into storage.buckets (id, name, public)
values ('photos','photos',true) on conflict (id) do nothing;

drop policy if exists "photos_public_read" on storage.objects;
create policy "photos_public_read" on storage.objects for select
  using (bucket_id = 'photos');

drop policy if exists "photos_admin_insert" on storage.objects;
create policy "photos_admin_insert" on storage.objects for insert
  with check (bucket_id = 'photos' and (auth.jwt() ->> 'email') in (select email from admins));

drop policy if exists "photos_admin_delete" on storage.objects;
create policy "photos_admin_delete" on storage.objects for delete
  using (bucket_id = 'photos' and (auth.jwt() ->> 'email') in (select email from admins));

-- ═══════════════ ACCÈS ADMIN ═══════════════
insert into admins (email) values
  ('julien.masr@gmail.com'),
  ('contact@horlo-gerie.fr')
on conflict (email) do nothing;

-- ═══════════════ MONTRES D'EXEMPLE (en brouillon) ═══════════════
-- Invisibles du public. À publier depuis /admin/ pour voir le site vivant,
-- ou à supprimer en une fois (tout cocher → Supprimer) quand le vrai stock est là.
insert into watches (slug, marque, modele, ref, annee, date_prod, date_source, prix, etat, acc, calibre, diam, revision, description, photos, status) values
('speedmaster-3570','Omega','Speedmaster Professional','3570.50.00',2004,'2004-06-18','carte de garantie',4900,'Très bon','full','1861, remontage manuel','42 mm','Révisée 03/2026','Hésalite et fond plein, comme la Moonwatch d''origine. Boîte et papiers d''époque, bracelet 1998/849 complet. Amplitude 275° cadran en haut, marche +3 s/j après révision.','{/img/speedy-bracelet.jpg}','brouillon'),
('sub-16610','Rolex','Submariner Date','16610',1998,'1998-03-12','papiers d''origine',9800,'Très bon','papiers','3135, automatique','40 mm','Révisée 11/2025','Lunette aluminium d''origine, légèrement passée. Verre saphir sans rayure, bracelet Oyster 93150 avec jeu réduit. Papiers d''origine, boîte non fournie.','{/img/sub-noir.jpg}','brouillon'),
('santos-moyen','Cartier','Santos de Cartier, moyen modèle','WSSA0029',2021,'2021-09-04','facture d''achat en boutique',5900,'Excellent','full','1847 MC, automatique','35,1 mm','Contrôlée 08/2026','Système QuickSwitch, second bracelet cuir noir fourni. Full set, facture d''achat en boutique.','{/img/santos.jpg}','brouillon'),
('bb58','Tudor','Black Bay Fifty-Eight','79030N',2020,'2020-11-27','carte de garantie',3100,'Très bon','full','MT5402, automatique','39 mm','Contrôlée 05/2026','Bracelet rivets acier, fermoir sans micro-rayure notable. Carte de garantie datée 2020, boîte et papiers.','{/img/bb58.jpg}','brouillon'),
('sub-16613','Rolex','Submariner Date acier & or','16613',1995,'1995-07-08','papiers d''origine',10900,'Bon','full','3135, automatique','40 mm','Révisée 06/2025','Cadran noir, index or. Traces d''usage cohérentes avec l''âge, boîtier jamais repoli. Full set : boîte, papiers, maillons, étiquettes.','{/img/sub-bicolore.jpg}','brouillon'),
('datejust-choco','Rolex','Datejust 31 cadran chocolat','178271',2016,'2016-04-21','carte de garantie',8400,'Excellent','full','2235, automatique','31 mm','Contrôlée 08/2026','Everose et acier, cadran chocolat index diamants. Portée quelques mois seulement, protections d''origine sur le fermoir.','{/img/datejust-choco.jpg}','brouillon'),
('speedy-racing','Omega','Speedmaster Racing Co-Axial','329.30.44.51.01.002',2019,'2019-10-02','garantie internationale',5400,'État neuf','full','9900, automatique','44,25 mm','Contrôlée 07/2026','Chronographe Master Chronometer certifié METAS. Aucune marque d''usage, garantie internationale encore en cours.','{/img/speedy-blanc.jpg}','brouillon'),
('navitimer-b01','Breitling','Navitimer B01 Chronograph 43','AB0121211G1P1',2019,'2019-05-16','carte de garantie',6300,'Excellent','full','B01, automatique','43 mm','Contrôlée 06/2026','Cadran argenté, règle à calcul circulaire intacte. Bracelet cuir noir d''origine, boucle déployante.','{/img/navitimer.jpg}','brouillon'),
('tank-louis','Cartier','Tank Louis Cartier, or jaune','W1529856',2012,'2012-12-07','papiers d''origine',7800,'Excellent','full','430 MC, remontage manuel','33,7 × 25,5 mm','Contrôlée 07/2026','Or jaune 18 ct, cadran argenté guilloché, chiffres romains. Écrin rouge et papiers d''origine.','{/img/ecrin.jpg}','brouillon'),
('datejust-16234','Rolex','Datejust 36','16234',2001,'2001-02-19','papiers d''origine',6900,'Très bon','papiers','3135, automatique','36 mm','Révisée 09/2025','Lunette cannelée or gris, cadran argent index bâtons. Bracelet Jubilé acier, jeu léger. Papiers d''origine.','{/img/datejust-bois.jpg}','brouillon'),
('speedmaster-1971','Omega','Speedmaster « pre-moon » tardive','145.022-71',1971,null,null,6200,'Bon','aucun','861, remontage manuel','42 mm','Révisée 12/2025','Cadran step, lunette DON remplacée en service. Extrait d''archives Omega fourni. Pièce vendue sans boîte.','{/img/mouvement.jpg}','brouillon'),
('longines-conquest','Longines','Conquest calendrier','9025',1962,null,null,1450,'Bon','aucun','19AS, automatique','35 mm','Révisée 01/2026','Boîtier acier, fond vissé avec médaillon émaillé. Cadran d''origine non restauré, quelques taches de patine honnêtes.','{/img/vintage-bois.jpg}','brouillon'),
('tissot-seastar','Tissot','Seastar automatique','44571-1X',1968,null,null,690,'Bon','aucun','784-2, automatique','34 mm','Révisée 02/2026','Cadran argenté légèrement patiné, aiguilles d''origine. Bracelet cuir neuf. Vendue sans boîte ni papiers, comme la plupart des pièces de cette époque.','{/img/vintage-noir.jpg}','brouillon'),
('seiko-lord-matic','Seiko','Lord Matic','5606-7000',1974,'1974-08-15','code de boîtier',420,'Bon','aucun','5606, automatique','36 mm','Révisée 04/2026','Cadran noir, jour-date bilingue. Révisée et étanchéité contrôlée. Une entrée en horlogerie mécanique qui ne triche pas.','{/img/pierre.jpg}','brouillon')
on conflict (slug) do nothing;
