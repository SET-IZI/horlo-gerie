'use client';
import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { logVisit } from '../lib/supabase';

// Enregistre les pages vues par un client connecté (aucun suivi pour un visiteur anonyme)
export default function VisitLogger() {
  const pathname = usePathname();
  useEffect(() => { logVisit(pathname); }, [pathname]);
  return null;
}
