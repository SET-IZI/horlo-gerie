'use client';
import { useEffect, useMemo, useState } from 'react';
import { getWatches } from '../../lib/supabase';
import { isVintage, C24_URL } from '../../lib/site-data';
import WatchCard from '../../components/WatchCard';
import Track from '../../components/Track';

const MARQUES = ['Rolex', 'Omega', 'Cartier', 'Tudor', 'Breitling'];

export default function Boutique() {
  const [watches, setWatches] = useState(null);
  const [brand, setBrand] = useState('');
  const [state, setState] = useState('');
  const [decade, setDecade] = useState(null);
  const [sort, setSort] = useState('recent');

  useEffect(() => {
    getWatches().then(setWatches);
    const q = new URLSearchParams(window.location.search);
    if (q.get('brand')) setBrand(q.get('brand'));
    if (q.get('decade')) setDecade(parseInt(q.get('decade'), 10));
  }, []);

  const liste = useMemo(() => {
    let l = (watches || []).filter(w => {
      if (brand === 'vintage') { if (!isVintage(w)) return false; }
      else if (brand && w.marque !== brand) return false;
      if (state === 'full' && w.acc !== 'full') return false;
      if (state === 'neuf' && w.etat !== 'État neuf') return false;
      if (decade !== null && (w.annee < decade || w.annee >= decade + 10)) return false;
      return true;
    });
    const S = {
      'price-asc': (a, b) => a.prix - b.prix,
      'price-desc': (a, b) => b.prix - a.prix,
      'year-asc': (a, b) => (a.annee || 0) - (b.annee || 0),
      'year-desc': (a, b) => (b.annee || 0) - (a.annee || 0),
    };
    return S[sort] ? [...l].sort(S[sort]) : l;
  }, [watches, brand, state, decade, sort]);

  function reset() { setBrand(''); setState(''); setDecade(null); }

  return (
    <>
      <div className="wrap shop-head">
        <div className="row">
          <div>
            <span className="eyebrow">Catalogue</span>
            <h1>La collection</h1>
            <p className="c24-note">
              Chaque pièce est également listée sur <b>Chrono24</b>, sous le même numéro de référence.
              {!C24_URL.trim() && <span className="soon">Profil en cours d’ouverture</span>}
            </p>
          </div>
          <div className="cnt">
            <b>{liste.length}</b>
            <span className="smallcaps">pièce{liste.length > 1 ? 's' : ''} disponible{liste.length > 1 ? 's' : ''}</span>
          </div>
        </div>
      </div>

      <div className="bar">
        <div className="wrap" id="filters">
          <button className="chip" aria-pressed={brand === ''} onClick={() => setBrand('')}>Toutes</button>
          {MARQUES.map(m => (
            <button key={m} className="chip" aria-pressed={brand === m} onClick={() => setBrand(m)}>{m}</button>
          ))}
          <button className="chip" aria-pressed={brand === 'vintage'} onClick={() => setBrand('vintage')}>Vintage</button>
          <span className="sep" />
          <button className="chip" aria-pressed={state === 'full'} onClick={() => setState(s => s === 'full' ? '' : 'full')}>Full set</button>
          <button className="chip" aria-pressed={state === 'neuf'} onClick={() => setState(s => s === 'neuf' ? '' : 'neuf')}>État neuf</button>
          <span className="grow" />
          <select value={sort} onChange={e => setSort(e.target.value)} aria-label="Trier la collection">
            <option value="recent">Trier : nouveautés</option>
            <option value="price-asc">Prix croissant</option>
            <option value="price-desc">Prix décroissant</option>
            <option value="year-asc">Année, ancienne → récente</option>
            <option value="year-desc">Année, récente → ancienne</option>
          </select>
        </div>
      </div>

      {(watches || []).length > 0 && (
        <div className="wrap shop-rail">
          <div className="hint">
            <span className="smallcaps">{decade !== null ? `Années ${decade}` : 'Toutes les décennies'}</span>
            {decade !== null && <button onClick={() => setDecade(null)}>Effacer la décennie</button>}
          </div>
          <Track
            watches={watches || []}
            activeDecade={decade}
            onDecade={d => setDecade(cur => (cur === d ? null : d))}
          />
        </div>
      )}

      <div className="wrap shop-grid">
        {watches === null ? (
          <p className="empty">Chargement…</p>
        ) : liste.length ? (
          <div className="grid-4">{liste.map(w => <WatchCard key={w.id} w={w} />)}</div>
        ) : (
          <div className="void">
            <p>Aucune pièce ne correspond à ces critères pour l’instant.</p>
            <button onClick={reset}>Réinitialiser les filtres</button>
          </div>
        )}
      </div>
    </>
  );
}
