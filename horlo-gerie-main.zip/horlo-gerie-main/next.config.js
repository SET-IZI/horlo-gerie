/** @type {import('next').NextConfig} */
const nextConfig = {
  // Export statique : le résultat de `npm run build` est un dossier `out/`
  // fait de fichiers HTML/CSS/JS purs, envoyable tel quel par FileZilla sur
  // n'importe quel hébergement mutualisé — pas besoin de serveur Node.
  output: 'export',
  trailingSlash: true, // .../boutique/index.html au lieu de .../boutique.html : plus fiable en FTP
  images: {
    unoptimized: true, // l'optimisation d'image de Next a besoin d'un serveur, indisponible en export statique
  },
};

module.exports = nextConfig;
