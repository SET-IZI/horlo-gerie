'use client';
import { useState } from 'react';

const LIENS = [
  { href: '/boutique/', label: 'La collection' },
  { href: '/vendues/', label: 'Ventes réalisées' },
  { href: '/marques/', label: 'Les marques' },
  { href: '/faq/', label: 'Questions' },
  { href: '/#controle', label: 'Notre contrôle' },
  { href: '/#depot', label: 'Déposer une montre' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <header className="head">
        <div className="wrap">
          <a className="logo" href="/"><span className="d" />Horlo-Gerie</a>

          <nav className="nav">
            {LIENS.slice(0, 4).map(l => <a key={l.href} href={l.href}>{l.label}</a>)}
          </nav>

          <div className="head-right">
            <a className="btn ghost" href="/compte/">Mon compte</a>
            <a className="btn ghost" href="mailto:contact@horlo-gerie.fr">Contact</a>
            <button
              className="burger"
              aria-label={open ? 'Fermer le menu' : 'Ouvrir le menu'}
              aria-expanded={open}
              onClick={() => setOpen(o => !o)}
            >
              <span />
            </button>
          </div>
        </div>
      </header>

      <div className={`drawer-menu${open ? ' on' : ''}`} onClick={() => setOpen(false)}>
        {LIENS.map(l => <a key={l.href} href={l.href}>{l.label}</a>)}
        <a href="/compte/">Mon compte</a>
        <a href="mailto:contact@horlo-gerie.fr">Contact</a>
      </div>
    </>
  );
}
