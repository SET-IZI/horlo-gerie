'use client';
import { useEffect, useState } from 'react';
import { supabase, toggleFavorite } from '../lib/supabase';

export default function FavButton({ watchId }) {
  const [connected, setConnected] = useState(null);
  const [fav, setFav] = useState(false);

  useEffect(() => {
    let vivant = true;
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!vivant) return;
      setConnected(!!user);
      if (user) {
        supabase.from('favoris').select('watch_id')
          .eq('client_id', user.id).eq('watch_id', watchId).maybeSingle()
          .then(({ data }) => { if (vivant) setFav(!!data); });
      }
    });
    return () => { vivant = false; };
  }, [watchId]);

  async function handleClick(e) {
    e.preventDefault(); e.stopPropagation();
    if (!connected) { window.location.href = '/compte/'; return; }
    const res = await toggleFavorite(watchId, fav);
    if (res && res.needAuth) { window.location.href = '/compte/'; return; }
    setFav(!fav);
  }

  return (
    <button
      type="button" className="fav" onClick={handleClick}
      aria-pressed={fav}
      aria-label={fav ? 'Retirer des favoris' : 'Ajouter aux favoris'}
    >
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12 20.5 4.2 13a4.8 4.8 0 0 1 6.8-6.8l1 1 1-1A4.8 4.8 0 1 1 19.8 13Z" />
      </svg>
    </button>
  );
}
