'use client';
import { useEffect, useState } from 'react';
import {
  getSession, onAuthChange, checkIsAdmin, signOut,
  searchClients, getClientDetail, eur, watchPhoto,
} from '../../../lib/supabase';

function ClientDetail({ client, onBack }) {
  const [detail, setDetail] = useState(null);

  useEffect(() => { getClientDetail(client.id).then(setDetail); }, [client.id]);

  return (
    <div>
      <button className="btn ghost sm" onClick={onBack} style={{ marginBottom: 20 }}>← Retour à la recherche</button>
      <h2>{client.nom || '(nom non renseigné)'}</h2>
      <p className="sub">
        {client.email}{client.telephone ? ` — ${client.telephone}` : ' — pas de téléphone renseigné'}
      </p>

      {!detail ? <p className="empty">Chargement…</p> : (
        <>
          <h3 style={{ marginTop: 28 }}>Favoris ({detail.favoris.length})</h3>
          {detail.favoris.length === 0 ? <p className="empty" style={{ padding: '14px 0' }}>Aucun favori.</p> : (
            <div style={{ display: 'grid', gap: 8, marginTop: 10 }}>
              {detail.favoris.map(w => (
                <a key={w.id} className="card" href={`/produit/?id=${w.slug}`} style={{ display: 'grid', gridTemplateColumns: '60px 1fr auto', gap: 12, padding: 10, alignItems: 'center' }}>
                  <img src={watchPhoto(w)} alt="" style={{ width: 52, height: 52, objectFit: 'cover' }} />
                  <span><b>{w.marque}</b> {w.modele}</span>
                  <span className="price">{eur(w.prix)}</span>
                </a>
              ))}
            </div>
          )}

          <h3 style={{ marginTop: 28 }}>Commandes ({detail.commandes.length})</h3>
          {detail.commandes.length === 0 ? <p className="empty" style={{ padding: '14px 0' }}>Aucune commande enregistrée.</p> : (
            <div className="specs" style={{ marginTop: 10 }}>
              {detail.commandes.map(c => (
                <div key={c.id}>
                  <b>{c.watches?.marque} {c.watches?.modele} {c.watches?.ref ? `— ${c.watches.ref}` : ''}</b>
                  <span>{eur(c.prix)} · {c.date ? new Date(c.date).toLocaleDateString('fr-FR') : ''}</span>
                </div>
              ))}
            </div>
          )}

          <h3 style={{ marginTop: 28 }}>Dernières pages visitées</h3>
          {detail.visites.length === 0 ? <p className="empty" style={{ padding: '14px 0' }}>Aucune visite enregistrée.</p> : (
            <div className="specs" style={{ marginTop: 10 }}>
              {detail.visites.map((v, i) => (
                <div key={i}>
                  <b>{v.chemin}</b>
                  <span>{new Date(v.created_at).toLocaleString('fr-FR')}</span>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Search() {
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (q.trim().length < 2) { setResults([]); return; }
    setSearching(true);
    const t = setTimeout(() => {
      searchClients(q).then(r => { setResults(r); setSearching(false); });
    }, 300);
    return () => clearTimeout(t);
  }, [q]);

  if (selected) return <div className="wrap" style={{ padding: '32px 0' }}><ClientDetail client={selected} onBack={() => setSelected(null)} /></div>;

  return (
    <div className="wrap" style={{ padding: '32px 0' }}>
      <div className="admin-head">
        <div>
          <span className="eyebrow">Espace admin</span>
          <h1>Rechercher un client</h1>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <a className="btn ghost" href="/admin/visiteurs/">Visiteurs</a>
          <a className="btn ghost" href="/admin/">← Annonces</a>
          <button className="btn ghost" onClick={() => signOut()}>Déconnexion</button>
        </div>
      </div>

      <input
        className="search-input" placeholder="Nom, e-mail ou téléphone…"
        value={q} onChange={e => setQ(e.target.value)} autoFocus
      />

      {searching && <p className="empty">Recherche…</p>}
      {!searching && q.trim().length >= 2 && results.length === 0 && (
        <p className="empty">Aucun client ne correspond à « {q} ».</p>
      )}

      {results.length > 0 && (
        <div className="admin-table-wrap" style={{ marginTop: 20 }}>
          <table className="admin-table">
            <thead><tr><th>Nom</th><th>E-mail</th><th>Téléphone</th><th></th></tr></thead>
            <tbody>
              {results.map(c => (
                <tr key={c.id}>
                  <td>{c.nom || <span className="sub">—</span>}</td>
                  <td>{c.email}</td>
                  <td>{c.telephone || <span className="sub">—</span>}</td>
                  <td className="actions"><button className="btn ghost sm" onClick={() => setSelected(c)}>Voir la fiche</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AdminClients() {
  const [state, setState] = useState('chargement');

  useEffect(() => {
    let sub;
    (async () => {
      const session = await getSession();
      await apply(session);
      sub = onAuthChange(apply);
    })();
    return () => sub?.unsubscribe();
  }, []);

  async function apply(session) {
    if (!session) { setState('non-connecte'); return; }
    const admin = await checkIsAdmin(session.user.email);
    setState(admin ? 'admin' : 'non-admin');
  }

  if (state === 'chargement') return <div className="wrap"><p className="empty">Chargement…</p></div>;
  if (state !== 'admin') {
    return (
      <div className="wrap" style={{ padding: '60px 0' }}>
        <h1>Accès non autorisé</h1>
        <p>Connecte-toi depuis <a href="/admin/">/admin/</a> avec un compte admin.</p>
      </div>
    );
  }
  return <Search />;
}
