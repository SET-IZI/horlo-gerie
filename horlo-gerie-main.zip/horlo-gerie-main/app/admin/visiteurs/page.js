'use client';
import { useEffect, useState } from 'react';
import { getSession, onAuthChange, checkIsAdmin, signOut, getAnonymousVisitors } from '../../../lib/supabase';

function Visitors() {
  const [groups, setGroups] = useState(null);

  useEffect(() => { getAnonymousVisitors().then(setGroups); }, []);

  return (
    <div className="wrap" style={{ padding: '32px 0' }}>
      <div className="admin-head">
        <div>
          <span className="eyebrow">Espace admin</span>
          <h1>Visiteurs non connectés</h1>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <a className="btn ghost" href="/admin/clients/">Rechercher un client</a>
          <a className="btn ghost" href="/admin/">← Annonces</a>
          <button className="btn ghost" onClick={() => signOut()}>Déconnexion</button>
        </div>
      </div>

      <div className="warn" style={{ marginBottom: 24 }}>
        <span className="m">!</span>
        <p>Une IP peut être partagée par plusieurs personnes (foyer, bureau, wifi public). Une « piste » ci-dessous est une supposition, jamais une identité confirmée.</p>
      </div>

      {groups === null ? (
        <p className="empty">Chargement…</p>
      ) : groups.length === 0 ? (
        <p className="empty">Aucune visite anonyme enregistrée pour l'instant.</p>
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead><tr><th>Adresse IP</th><th>Piste(s) client</th><th>Pages vues</th><th>Dernière visite</th></tr></thead>
            <tbody>
              {groups.map(g => (
                <tr key={g.ip}>
                  <td><code>{g.ip}</code></td>
                  <td>
                    {g.pistes.length === 0
                      ? <span className="sub">—</span>
                      : g.pistes.map(c => <div key={c.email}>{c.nom || c.email}</div>)}
                  </td>
                  <td>{g.count} {g.count > 1 ? 'pages' : 'page'}<div className="sub">{[...new Set(g.pages.slice(0, 4).map(p => p.chemin))].join(', ')}</div></td>
                  <td>{new Date(g.dernier).toLocaleString('fr-FR')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AdminVisiteurs() {
  const [state, setState] = useState('chargement');

  useEffect(() => {
    let sub;
    (async () => {
      const session = await getSession();
      await apply(session);
      sub = onAuthChange(apply);
    })();
    return () => sub?.unsubscribe();
  }, []);

  async function apply(session) {
    if (!session) { setState('non-connecte'); return; }
    const admin = await checkIsAdmin(session.user.email);
    setState(admin ? 'admin' : 'non-admin');
  }

  if (state === 'chargement') return <div className="wrap"><p className="empty">Chargement…</p></div>;
  if (state !== 'admin') {
    return (
      <div className="wrap" style={{ padding: '60px 0' }}>
        <h1>Accès non autorisé</h1>
        <p>Connecte-toi depuis <a href="/admin/">/admin/</a> avec un compte admin.</p>
      </div>
    );
  }
  return <Visitors />;
}
