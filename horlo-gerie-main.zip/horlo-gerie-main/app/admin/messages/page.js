'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  supabase, getSession, onAuthChange, checkIsAdmin, signOut,
  getAdminThreads, getThreadMessages, replyToClient, markThreadRead, heureFr,
} from '../../../lib/supabase';

function Inbox() {
  const [threads, setThreads] = useState(null);
  const [actif, setActif] = useState(null);
  const [messages, setMessages] = useState([]);
  const [texte, setTexte] = useState('');
  const logRef = useRef(null);

  const recharger = useCallback(async () => { setThreads(await getAdminThreads()); }, []);
  useEffect(() => { recharger(); }, [recharger]);

  useEffect(() => {
    const canal = supabase
      .channel('messages-admin')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => {
        recharger();
        if (actif) getThreadMessages(actif.client_id).then(setMessages);
      })
      .subscribe();
    return () => { supabase.removeChannel(canal); };
  }, [actif, recharger]);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [messages]);

  async function ouvrir(t) {
    setActif(t);
    setMessages(await getThreadMessages(t.client_id));
    await markThreadRead(t.client_id);
    recharger();
  }

  async function repondre(e) {
    e.preventDefault();
    const v = texte.trim();
    if (!v || !actif) return;
    setTexte('');
    setMessages(m => [...m, { id: 'tmp' + Date.now(), auteur: 'admin', texte: v, created_at: new Date().toISOString() }]);
    await replyToClient(actif.client_id, v);
    setMessages(await getThreadMessages(actif.client_id));
    recharger();
  }

  const nom = t => (t.client && (t.client.nom || t.client.email)) || 'Client';

  return (
    <div className="wrap" style={{ padding: '32px 0' }}>
      <div className="admin-head">
        <div>
          <span className="eyebrow">Espace admin</span>
          <h1>Messages</h1>
        </div>
        <div className="admin-head-actions">
          <a className="btn ghost" href="/admin/">Annonces</a>
          <a className="btn ghost" href="/admin/clients/">Clients</a>
          <a className="btn ghost" href="/admin/visiteurs/">Visiteurs</a>
          <button className="btn ghost" onClick={() => signOut()}>Déconnexion</button>
        </div>
      </div>

      {threads === null ? (
        <p className="empty">Chargement…</p>
      ) : threads.length === 0 ? (
        <div className="empty-state"><p>Aucune conversation pour l’instant.</p></div>
      ) : (
        <div className="inbox">
          <div className="inbox-list">
            {threads.map(t => (
              <button
                key={t.client_id} className="thread-item"
                aria-selected={actif && actif.client_id === t.client_id}
                onClick={() => ouvrir(t)}
              >
                <div className="l1">
                  <span className="nm">{nom(t)}</span>
                  <span className="dt">{heureFr(t.dernier.created_at)}</span>
                </div>
                <div className="pv">
                  <span className="chan">{t.dernier.auteur === 'admin' ? 'Vous' : 'Tchat'}</span>
                  {t.dernier.texte}
                </div>
                {t.nonLus > 0 && <span className="unread">{t.nonLus} non lu{t.nonLus > 1 ? 's' : ''}</span>}
              </button>
            ))}
          </div>

          <div className="thread-view">
            {!actif ? (
              <p className="empty">Choisissez une conversation à gauche.</p>
            ) : (
              <>
                <div className="thread-head">
                  <div>
                    <b>{nom(actif)}</b>
                    <span>{actif.client ? actif.client.email : ''}{actif.client && actif.client.telephone ? ` · ${actif.client.telephone}` : ''}</span>
                  </div>
                  <a className="btn ghost sm" href="/admin/clients/">Voir sa fiche</a>
                </div>

                <div className="thread-log" ref={logRef}>
                  {messages.map(m => (
                    <div key={m.id} className={`msg ${m.auteur === 'admin' ? 'me' : 'them'}`}>
                      {m.texte}
                      <span className="t">{heureFr(m.created_at)}</span>
                    </div>
                  ))}
                </div>

                <form className="thread-reply" onSubmit={repondre}>
                  <input
                    value={texte} onChange={e => setTexte(e.target.value)}
                    placeholder="Votre réponse…" aria-label="Votre réponse" autoComplete="off"
                  />
                  <button className="btn" type="submit">Envoyer</button>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function Messages() {
  const [state, setState] = useState('chargement');

  useEffect(() => {
    let sub;
    (async () => {
      await handle(await getSession());
      sub = onAuthChange(handle);
    })();
    return () => sub?.unsubscribe();
  }, []);

  async function handle(session) {
    if (!session) { setState('non-connecte'); return; }
    setState(await checkIsAdmin(session.user.email) ? 'admin' : 'non-admin');
  }

  if (state === 'chargement') return <div className="wrap"><p className="empty">Chargement…</p></div>;
  if (state !== 'admin') {
    return (
      <div className="wrap" style={{ padding: '60px 0' }}>
        <h1>Accès réservé</h1>
        <p>Connectez-vous avec un compte admin depuis <a href="/admin/" style={{ textDecoration: 'underline' }}>la page d’administration</a>.</p>
      </div>
    );
  }
  return <Inbox />;
}
