import Newsletter from './Newsletter';
import C24Link from './C24Link';

export default function Footer() {
  return (
    <footer>
      <div className="wrap">
        <div>
          <div className="logo"><span className="d" />Horlo-Gerie</div>
          <p style={{ maxWidth: '30em', margin: '0 0 16px' }}>
            Dépôt-vente de montres d’occasion et en état neuf. Paiement sécurisé via Shopify,
            expédition assurée en France et en Europe.
          </p>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: 6 }}>
            <li><a href="mailto:contact@horlo-gerie.fr">contact@horlo-gerie.fr</a></li>
            <li>Paris · Lille · Bruxelles — sur rendez-vous</li>
            <li>Londres — ouverture en cours</li>
            <li>Lun.–Sam. 10 h – 19 h</li>
          </ul>
          <div className="elsewhere">
            <span className="smallcaps">Retrouvez-nous</span>
            <C24Link />
          </div>
        </div>

        <div><h4>Collection</h4><ul>
          <li><a href="/boutique/">Toutes les pièces</a></li>
          <li><a href="/vendues/">Ventes réalisées</a></li>
          <li><a href="/marques/">Toutes les marques</a></li>
          <li><a href="/boutique/?brand=Rolex">Rolex</a></li>
          <li><a href="/boutique/?brand=Omega">Omega</a></li>
          <li><a href="/boutique/?brand=Cartier">Cartier</a></li>
          <li><a href="/boutique/?brand=vintage">Vintage</a></li>
        </ul></div>

        <div><h4>La maison</h4><ul>
          <li><a href="/#controle">Notre contrôle</a></li>
          <li><a href="/#depot">Déposer une montre</a></li>
          <li><a href="/#maison">Qui sommes-nous</a></li>
          <li><a href="/faq/">Questions fréquentes</a></li>
          <li><a href="mailto:contact@horlo-gerie.fr">Nous écrire</a></li>
        </ul></div>

        <Newsletter />

        <div className="bottom">
          <span>© {new Date().getFullYear()} Horlo-Gerie</span>
          <span>
            <a href="/conditions/">Conditions de vente</a> ·{' '}
            <a href="/conditions/#art-12">Données personnelles</a> ·{' '}
            <a href="/conditions/#art-1">Mentions légales</a> ·{' '}
            <a href="/admin/" style={{ opacity: .45 }}>Admin</a>
          </span>
        </div>
      </div>
    </footer>
  );
}
